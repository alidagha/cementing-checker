"""Canonical project state, calculation refresh and review of edited report text."""
from datetime import date, datetime
from copy import deepcopy
import hashlib
import json
import math
import numpy as np
import pandas as pd
import materials_db
from well_profile import geometry_defaults, geothermal_defaults, resolve_well_profile
from rheology import validate_rheology_results
from engineering_tools import (require_positive_density, require_fluid_density, require_bhsp_density, require_positive_pump_rate,
                               require_preflush_material_name, require_spacer_material_name,
                               format_to_hr_mm, round_half_up, safe_float,
                               validate_lab_masses, validate_thickening_test, parse_effective_numeric,
                               validate_lab_collection_results, THICKENING_TEST_FIELDS, validate_compressive_test,
                               validate_lab_rheology, lab_temperature_valid, lab_review_signature,
                               MATERIAL_PROPERTY_SCHEMA, LEGACY_ADDITIVE_SG,
                               catalog_cement_sg, resolve_cement_sg, default_additive_density_gcm3,
                               is_salt_additive, SALT_MODEL_VERSION)

SLURRIES = materials_db.CEMENT_FORMULATION_FLUIDS


DOCUMENT_DETAIL_FIELDS = (
    ("Request Date Received", "request_date"),
    ("Request Number", "request_number"),
    ("Request Description", "request_description"),
    ("Prepared Date", "prepared_date"),
    ("Prepared Phone", "prepared_phone"),
    ("Checked Date", "checked_date"),
    ("Checked Phone", "checked_phone"),
    ("Approved Date", "approved_date"),
    ("Approved Phone", "approved_phone"),
    ("Revision Date", "revision_date"),
    ("Revision Description", "revision_description"),
)


def request_description_for_job(job_type):
    """Format catalog job families; retain future job names unchanged."""
    if job_type in materials_db.JOB_TYPES:
        for prefix in ("TIE BACK LNR ", "CSG ", "LNR "):
            if job_type.startswith(prefix):
                return f"{job_type[len(prefix):]} {prefix.strip()} Cementing"
    return f"{job_type} Cementing"


DOC_CONTROL_DEFAULTS = {
    "job_type": "CSG 20\"",
    "hole_size": "26\"",
    "field": "",
    "well_location": "",
    "well_name": "",
    "rig_name": "",
    "client": "",
    "contract_number": "",
    "proposal_number": "",
    "cementing_method": "Primary Cementing",
    "district_phone": "061-341-43513",
    "made_by": "NIDC Cement Engineering and Planning Department",
    # FIX (requested): a formal engineering document needs an approval
    # chain and a revision marker, not just a single "Made By" line, to
    # go from "internal draft" to "citable record". Revision defaults to
    # "0" (the first issue of a document) rather than blank, since every
    # real document has *some* revision number from the start.
    "prepared_by": "",
    "checked_by": "M.Hasannezhad",
    "approved_by": "Sh.Jalili",
    "revision_no": "0"
}


DOC_CONTROL_DEFAULTS.update({key: "" for _, key in DOCUMENT_DETAIL_FIELDS})
DOC_CONTROL_DEFAULTS.update(checked_phone="+98-916-604-7042", approved_phone="+98-917-142-1265")
DOC_CONTROL_DEFAULTS["request_description"] = request_description_for_job(DOC_CONTROL_DEFAULTS["job_type"])
DOC_CONTROL_DEFAULTS["revision_description"] = DOC_CONTROL_DEFAULTS["request_description"]

WELL_DATA_DEFAULTS = {
    "mud_type": "WBM",
    "mud_density": "",
    "plastic_viscosity": "",
    "yield_point": "",
    "geo_md": None,
    "geo_tvd": None,
    "bhst": None,
    "bhct": None,
    "pore_gradient_emw_pcf": None,
    "frac_gradient_emw_pcf": None,
    "geo_gradient": None,
    "bhsp": ""
}


def refresh_well_derived(state):
    """Rebuild projections from explicit Round 7A sources, then automatic BHSP."""
    geometry = state.setdefault("well_geometry", geometry_defaults())
    geothermal = state.setdefault("geothermal_config", geothermal_defaults())
    for record, defaults in ((geometry, geometry_defaults()), (geothermal, geothermal_defaults())):
        if isinstance(record, dict):
            for key, value in defaults.items():
                record.setdefault(key, value)
    signature = fingerprint({"geometry": geometry, "geothermal": geothermal})
    if state.get("_well_profile_source") != signature:
        invalidate_document(state)
    state["_well_profile_source"] = signature
    projections, survey, issues = resolve_well_profile(geometry, geothermal)
    state.update(projections)
    well = state.setdefault("well_data", {})
    well.update(projections)
    state["_survey_result"] = survey
    state["_well_profile_issues"] = issues
    auto = state.setdefault("well_auto_fields", {"bhsp": "bhsp" not in state})
    auto.pop("geo_gradient", None)  # Temperature Source supersedes this provenance.
    pressure = ""
    tvd = projections["geo_tvd"]
    if tvd is not None and math.isfinite(tvd) and tvd > 0:
        try:
            pressure_value = tvd * require_bhsp_density(state.get("mud_density", "")) * 0.02278
            pressure = str(pressure_value) if math.isfinite(pressure_value) else ""
        except (TypeError, ValueError, OverflowError):
            pass  # Invalid/unfinished sources stay empty and block readiness.
    if auto.get("bhsp", False):
        state["bhsp"] = well["bhsp"] = pressure
    return issues


def restore_canonical_fields(state):
    """Fill missing flat fields from legacy snapshots; explicit flat values win."""
    for name, defaults in (("doc_control", DOC_CONTROL_DEFAULTS), ("well_data", WELL_DATA_DEFAULTS)):
        nested = state.get(name)
        if not isinstance(nested, dict):
            continue
        for key in defaults:
            if key in ("geo_md", "geo_tvd", "bhst", "geo_gradient"):
                continue
            if key not in state and key in nested:
                state[key] = nested[key]
            if key in state:
                nested[key] = state[key]
    doc = state.get("doc_control", {})
    if isinstance(doc, dict):
        if "report_date" not in state and doc.get("date"):
            state["report_date"] = date.fromisoformat(str(doc["date"]))
        if "report_date" in state:
            state["doc_control"] = doc
            value = state["report_date"]
            doc["date"] = (value.isoformat() if isinstance(value, (date, datetime))
                           else "" if value is None else str(value))
    well = state.get("well_data", {})
    if isinstance(well, dict):
        for field, effective, default in (("mud_density", "effective_mud_density", None),
                                           ("plastic_viscosity", "effective_pv", None),
                                           ("yield_point", "effective_yp", None)):
            if field in state:
                state[effective] = parse_effective_numeric(state[field], default=default)
                well[effective] = state[effective]
    if (any(key in state for key in ("well_geometry", "geothermal_config", "geo_md", "geo_tvd", "bhst", "geo_gradient"))
            or any(key in well for key in ("geo_md", "geo_tvd", "bhst", "geo_gradient"))):
        refresh_well_derived(state)
    reconcile_fluid_applicability(state)
    reconcile_ct_stage_selection(state)


def reconcile_ct_stage_selection(state):
    """Retire a CT choice on a real source transition; never choose another count."""
    from ct_stages import CONFIG_KEY, main_volume
    if CONFIG_KEY not in state:
        return
    record = state[CONFIG_KEY]
    inactive = (state.get("job_type") != materials_db.CT_JOB
                or "Main" not in state.get("fluids_config", {}).get("active", []))
    changed = False
    if isinstance(record, dict) and isinstance(record.get("main_volume"), str):
        try:
            volume = main_volume(state)
        except ValueError:
            changed = True  # An invalid source edit cannot preserve a prior choice.
        else:
            try:
                from decimal import Decimal
                changed = volume <= 12 or volume != Decimal(record["main_volume"])
            except ArithmeticError:
                pass  # Malformed records remain blocked by validation.
    if inactive or changed:
        state.pop(CONFIG_KEY, None)
        state.pop("cement_note_Main", None)
        invalidate_document(state)


def available_fluid_types(state):
    """Project Mud Type governs eligibility; ordering stays in materials_db."""
    mud_type = state.get("mud_type", state.get("well_data", {}).get("mud_type", "WBM"))
    return [name for name in materials_db.FLUID_TYPES
            if (name != "Diesel" or mud_type == "OBM")
            and (state.get("job_type") != materials_db.CT_JOB
                 or name not in materials_db.CEMENT_FORMULATION_FLUIDS or name == "Main")]


def reconcile_fluid_applicability(state):
    """Reconcile one selection per fluid and deactivate ineligible Diesel.

    Used before decoded state publication, on Mud Type edits and on rebuild;
    parameter/lab drafts survive and OBM eligibility never reactivates Diesel.
    """
    cfg = state.get("fluids_config", {})
    active = cfg.get("active", [])
    if state.get("job_type") == materials_db.CT_JOB:
        forbidden = [name for name in active if name in materials_db.CEMENT_FORMULATION_FLUIDS and name != "Main"]
        if forbidden:
            cfg["active"] = [name for name in active if name not in forbidden]
            purge_inactive_slurries(state, cfg["active"])
            for name in forbidden:
                state.pop("chk_fluid_" + name, None)
                state.get("fluid_data", {}).pop(name, None)
                state.get("active_fluids", {}).pop(name, None)
            invalidate_document(state)
            active = cfg["active"]
    unique = list(dict.fromkeys(active))
    if unique != active:
        cfg["active"] = unique
        invalidate_document(state)
    if "Diesel" in available_fluid_types(state):
        return
    if "Diesel" in cfg.get("active", []):
        cfg["active"] = [name for name in cfg["active"] if name != "Diesel"]
        invalidate_document(state)
    state.pop("chk_fluid_Diesel", None)
    if "Diesel" in state.get("active_fluids", {}):
        state["active_fluids"]["Diesel"] = False
    state.get("fluid_data", {}).pop("Diesel", None)


def _canonical(value):
    if isinstance(value, pd.DataFrame):
        return {"columns": list(value.columns), "rows": _canonical(value.to_dict("records"))}
    if isinstance(value, np.ndarray):
        return {"shape": list(value.shape), "items": _canonical(value.tolist())}
    if isinstance(value, dict):
        return {str(k): _canonical(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonical(v) for v in value]
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if value is pd.NA:
        return {"missing": True}
    if isinstance(value, bool):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            return {"nonfinite": str(value)}
        return 0.0 if value == 0.0 else value
    if isinstance(value, int):
        # BUG-16: fingerprint(150) and fingerprint(150.0) must be identical —
        # widget sources legitimately deliver the same quantity as int or
        # float, and a signature flip on int/float alone produced false
        # drift. Floats outside exact-int representation stay distinct.
        return float(value) if abs(value) <= 2 ** 53 else str(value)
    if hasattr(value, "item"):
        return _canonical(value.item())
    if value is None or isinstance(value, str):
        return value
    return str(value)


def fingerprint(value):
    encoded = json.dumps(_canonical(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def hardware_draft_pending(state):
    """A browser draft is not validated hardware until Phase II/III reviews it."""
    draft = state.get("hardware_editor_draft")
    return isinstance(draft, pd.DataFrame) and fingerprint(draft) != fingerprint(state.get("hardware_table"))


def is_project_key(key):
    """Exclude current and legacy widget keys at both save and load boundaries."""
    transient = ("_", "$$ID", "FormSubmitter:", "proj_uploader", "last_loaded_hash", "chk_fluid_",
                 "vol_", "den_", "rate_", "matname_", "fix_den_",
                 "cemb_", "sg_", "tank_choice_", "dv_", "override_", "yd_ov_", "mw_ov_")
    return isinstance(key, str) and key != "app_mode_key" and not key.startswith(transient)


def reconcile_formation_profile(state):
    """Reconcile UI endpoint rows with the existing exposed-domain authority only.

    Survey changes never rewrite source pressures. Malformed intermediate order
    stays repairable; this function never sorts user entries.
    """
    from cement_chart_model import current_open_hole_domain
    config = state.get("formation_pressure_config")
    if not isinstance(config, dict) or config.get("mode") != "advanced":
        return None
    domain = current_open_hole_domain(state)
    if domain is None:
        return None
    rows = config["profile"]
    bounds = (domain["top_md"], domain["bottom_md"])
    previous = state.get("_formation_domain")
    has_endpoints = len(rows) >= 2 and (rows[0]["md_m"], rows[-1]["md_m"]) == bounds
    if not rows or (previous != bounds if previous is not None else not has_endpoints):
        # A first-entry draft need not contain endpoints. Only known prior
        # domain boundaries establish former endpoint identity.
        old_endpoints = rows if previous is None else [row for row in rows if row["md_m"] in previous]
        endpoints = {row["md_m"]: row for row in old_endpoints if row["md_m"] in bounds}
        candidates = rows if previous is None else [row for row in rows if row["md_m"] not in previous]
        interior = [deepcopy(row) for row in candidates if row["md_m"] is None or
                    (bounds[0] < row["md_m"] < bounds[1] and any(
                        part["top_md"] <= row["md_m"] <= part["bottom_md"] for part in domain["segments"]))]
        config["profile"] = [deepcopy(endpoints.get(bounds[0], {"md_m": bounds[0], "pore_psi": None, "frac_psi": None})),
                             *interior,
                             deepcopy(endpoints.get(bounds[1], {"md_m": bounds[1], "pore_psi": None, "frac_psi": None}))]
        state["_formation_epoch"] = state.get("_formation_epoch", 0)+1
        invalidate_document(state)
    state["_formation_domain"] = bounds
    return domain


def invalidate_document(state):
    for key in ("_compiled_doc_bytes", "_compiled_doc_filename", "_compiled_doc_signature"):
        state.pop(key, None)


def validate_material_properties(state):
    """Current property provenance is explicit; only version zero is historical."""
    version = state.get("material_property_schema", 0)
    if type(version) is not int or version not in (0, MATERIAL_PROPERTY_SCHEMA):
        raise ValueError("Unsupported material_property_schema")
    if version == MATERIAL_PROPERTY_SCHEMA:
        records = list(state.get("cement_params", {}).values())
        records += [draft["cement_params"] for draft in state.get("inactive_slurry_drafts", {}).values()
                    if "cement_params" in draft]
        for params in records:
            if params.get("cmt_sg_source") not in ("catalog", "manual"):
                raise ValueError("cmt_sg_source must be catalog or manual")
            if "cmt_sg" not in params:
                raise ValueError("Current cement parameters require cmt_sg")


def migrate_material_properties(state):
    """Migrate active and archived catalog defaults once, before any consumer."""
    validate_material_properties(state)
    if state.get("material_property_schema", 0) == MATERIAL_PROPERTY_SCHEMA:
        return False
    params = deepcopy(state.get("cement_params", {}))
    additives = deepcopy(state.get("cement_additives_dfs", {}))
    drafts = deepcopy(state.get("inactive_slurry_drafts", {}))

    def migrate_record(p, df):
        if p is not None:
            name = p.get("base_cement", "Cement G Delijan")
            known = materials_db.resolve_known_material(name)
            name = known[0] if known is not None else name
            sg = p.get("cmt_sg", 3.20)
            catalog = ("cmt_sg" not in p or (name == "Cement G Delijan" and sg == 3.20)
                       or (name == "Cement D Delijan" and sg == 3.16))
            p["cmt_sg_source"] = "catalog" if catalog else "manual"
            p["cmt_sg"] = catalog_cement_sg(name) if catalog else sg
        if isinstance(df, pd.DataFrame):
            if "Density" not in df:
                df["Density"] = None
            for index, row in df.iterrows():
                match = materials_db.resolve_known_material(row.get("Name"))
                if match is None or match[0] not in LEGACY_ADDITIVE_SG:
                    continue
                name, _, physical = match
                value = row.get("Density")
                if pd.isna(value) or value == "" or value == LEGACY_ADDITIVE_SG[name]:
                    df.at[index, "Density"] = default_additive_density_gcm3(name, physical)

    for slurry in params.keys() | additives.keys():
        migrate_record(params.get(slurry), additives.get(slurry))
    for draft in drafts.values():
        migrate_record(draft.get("cement_params"), draft.get("cement_additives_dfs"))
    # Publish only after every record has migrated successfully.
    for key, value in (("cement_params", params), ("cement_additives_dfs", additives),
                       ("inactive_slurry_drafts", drafts)):
        if key in state:
            state[key] = value
    for slurry in params.keys() | additives.keys():
        token = "".join(c if c.isalnum() else "_" for c in slurry).lower()
        key = f"_editor_additives_slurry_{token}_revision"
        state[key] = state.get(key, 0) + 1
        key = f"_cmt_sg_revision_{token}"
        state[key] = state.get(key, 0) + 1
    state["material_property_schema"] = MATERIAL_PROPERTY_SCHEMA
    invalidate_document(state)
    return True


def purge_inactive_slurries(state, active):
    # Standalone Spacer follows the existing generic Spacer cleanup policy,
    # rather than cement's archived-formulation policy.
    if "Spacer" not in active:
        state.pop("standalone_spacer_config", None)
        state.pop("lab_payload_Spacer", None)
        state.get("lab_source_signatures", {}).pop("Spacer", None)
        spacer_qc = state.get("lab_qc_params", {}).get("Spacer")
        if isinstance(spacer_qc, dict):
            spacer_qc["reviewed"] = False
        for key in list(state):
            if str(key).startswith(("_standalone_spacer_", "_rheo_spacer_", "_editor_lab_tbl_spacer_",
                                    "_editor_source__editor_lab_tbl_spacer_")):
                state.pop(key, None)
    saved_fields = ("cement_additives_dfs", "cement_params", "lab_grid_dfs", "lab_qc_params")
    for key in (*saved_fields, "lab_source_signatures"):
        if not isinstance(state.get(key, {}), dict):
            raise ValueError(f"{key} must be a dictionary; review or reload the project")
    for key in ("cement_initialized_slurries", "lab_initialized_slurries"):
        if not isinstance(state.get(key, []), list):
            raise ValueError(f"{key} must be a list; review or reload the project")
    drafts = state.setdefault("inactive_slurry_drafts", {})
    if not isinstance(drafts, dict):
        raise ValueError("inactive_slurry_drafts must be a dictionary; review or reload the project")
    for slurry in SLURRIES:
        if slurry in active:
            draft = drafts.get(slurry)
            if draft is not None:
                if not isinstance(draft, dict):
                    raise ValueError(f"{slurry}: inactive draft is invalid; review or reload the project")
                restored_lab = False
                for key in saved_fields:
                    if key in draft and slurry not in state.setdefault(key, {}):
                        state[key][slurry] = deepcopy(draft[key])
                        restored_lab |= key in ("lab_grid_dfs", "lab_qc_params")
                # The restored lab values remain visible, but must be reviewed
                # before export even if the engineer toggled the fluid back on
                # without changing density, additives or well conditions.
                if restored_lab:
                    state.setdefault("lab_source_signatures", {}).pop(slurry, None)
                drafts.pop(slurry)
            continue
        snapshot = {key: deepcopy(state[key][slurry]) for key in saved_fields
                    if slurry in state.get(key, {})}
        if snapshot:
            drafts[slurry] = snapshot
        for prefix in ("cement_calc_", "cement_raw_calc_", "cement_blend_", "cement_note_", "lab_payload_", "_p7_synced_sig_", "_lab_grid_revision_"):
            state.pop(prefix + slurry, None)
        for key in ("cement_additives_dfs", "cement_params", "lab_grid_dfs", "lab_qc_params", "lab_source_signatures"):
            state.get(key, {}).pop(slurry, None)
        for key in ("cement_initialized_slurries", "lab_initialized_slurries"):
            if slurry in state.get(key, []):
                state[key].remove(slurry)
        token = "".join(c if c.isalnum() else "_" for c in slurry).lower()
        stems = [f"{p}_{token}_" for p in ("cemb", "sg", "tank_choice", "dv", "override", "yd_ov", "mw_ov")]
        stems += ["_" + p for p in stems]
        stems += [f"_editor_additives_{token}_", f"_editor_lab_tbl_{token}_", f"_sync_btn_{token}_"]
        stems += [f"_rheo_{token}_", f"_comp_{token}_"]
        stems += [f"_report_bottom_slurry_{token}_"]
        stems += [f"_qc_{p}_in_{token}_" for p in ("bhct", "fl", "fw", "fw45", "surface_hours", "comp", "tt", "tt_endpoint")]
        stems += [f"_qc_{field}_in_{token}_" for field, _, _ in THICKENING_TEST_FIELDS]
        # BUG-15: the phase V/VI editors additionally keep a revision counter
        # and editor_state keeps a "_editor_source_" mirror of every editor
        # key; none of these matched the stems above and survived the purge.
        stems += [f"_editor_additives_slurry_{token}_revision",
                  f"_editor_source__editor_additives_{token}_",
                  f"_editor_source__editor_lab_tbl_{token}_"]
        for key in list(state):
            k = str(key)
            for stem in stems:
                if k.startswith(stem):
                    remainder = k[len(stem):]
                    # BUG-24: slugified tokens collide as literal prefixes —
                    # "Lead #1" becomes "lead__1", so the stem "..._lead_"
                    # also prefix-matches "..._lead__1_...". A remainder that
                    # continues with "_" is a DIFFERENT slurry's key and must
                    # survive. (Exact revision keys leave an empty remainder.)
                    if remainder.startswith("_"):
                        continue
                    state.pop(key, None)
                    break


def require_ct_report_implementation(state, job_type=None):
    """Every direct CT report consumer rebuilds and validates canonical inputs.

    Keep the B1 entry point, replacing its temporary block with B4 admission.
    In particular, calculations_prepared=True is not a CT validation bypass.
    """
    if (state.get("job_type") if job_type is None else job_type) == materials_db.CT_JOB:
        if state.get("job_type") != materials_db.CT_JOB:
            invalidate_document(state)
            raise ValueError("CT report requires the current CMT PLUG WITH CT project.")
        issues = prepare_calculations(state)
        if issues:
            invalidate_document(state)
            raise ValueError(" | ".join(issues))


def refresh_fluids(state):
    """Same phase-IV calculation, fed by its canonical inputs rather than caches.

    F-02 (system audit 2026-09-29, owner-approved): every ValueError raised
    here is prefixed 'Phase IV:' so that when prepare_calculations wraps it,
    the Phase X issue still carries the phase token and _phase_for_issue can
    resolve the deep-link rescue button. Before this, messages like
    '{name}: active fluid volume must be positive ...' surfaced as
    'Review the current calculation inputs before export (...)': the operator
    was told WHAT was wrong but never WHERE to go (audit L8-03)."""
    reconcile_ct_stage_selection(state)
    if state.get("job_type") == materials_db.CT_JOB:
        forbidden = [name for name in state.get("fluids_config", {}).get("active", [])
                     if name in materials_db.CEMENT_FORMULATION_FLUIDS and name != "Main"]
        if forbidden:
            invalidate_document(state)
            raise ValueError("Phase IV: CMT PLUG WITH CT permits only Main cement slurry; deselect " + ", ".join(forbidden))
    reconcile_fluid_applicability(state)
    cfg = state.get("fluids_config", {})
    active = sorted(cfg.get("active", []), key=materials_db.HYDRAULIC_EXECUTION_ORDER.index)
    cfg["active"] = active
    if not active:
        raise ValueError("Phase IV: select and configure the fluid train before export")
    old = state.get("fluid_data", {})
    result = {}
    cumulative = 0.0
    for name in active:
        # Old projects may have fluid_data but no params entry; preserve those inputs.
        source = cfg.get("params", {}).get(name, old.get(name, {}))
        if not isinstance(source, dict):
            raise ValueError(f"Phase IV: {name}: review the fluid inputs before export")
        if source.get("volume") in (None, ""):
            raise ValueError(f"Phase IV: {name}: enter the fluid volume before export")
        # F-02: a textual volume (malformed JSON stranded in fluid_data) used
        # to escape here as a RAW float() ValueError — an uncontrolled
        # message with no phase token, killing the deep-link rescue path.
        # Give it the same controlled, prefixed treatment as every other
        # gate in this function (offender named, repair location stated).
        volume = safe_float(source["volume"], None)
        if volume is None:
            raise ValueError(f"Phase IV: {name}: unreadable fluid volume "
                             f"({source['volume']!r}) — open Phase IV to repair it")
        density = source.get("density")
        if name == "Displacement Fluid":
            density = state.get("mud_density") or state.get("well_data", {}).get("mud_density")
        if density is None or not str(density).strip():
            raise ValueError(f"Phase IV: {name}: enter the fluid density before export")
        density = str(density)
        effective = require_fluid_density(name, density)
        if source.get("pump_rate") is None or not str(source["pump_rate"]).strip():
            raise ValueError(f"Phase IV: {name}: enter the pump rate before export")
        rate = str(source["pump_rate"])
        try:
            minimum = require_positive_pump_rate(rate)
        except ValueError as exc:
            if name == "Diesel":
                raise ValueError(f"Phase IV: Diesel: {exc}") from exc
            raise
        if not math.isfinite(volume) or volume <= 0:
            raise ValueError(f"Phase IV: {name}: active fluid volume must be positive; "
                             "enter a volume or deselect the fluid")
        material_name = source.get("material_name", materials_db.DEFAULT_MATERIAL_NAMES.get(name, ""))
        if name == "Diesel":
            material_name = materials_db.DEFAULT_MATERIAL_NAMES[name]
        elif name == "Pre Flush":
            require_preflush_material_name(material_name)
        if name in ("Spacer Ahead", "Spacer Behind"):
            require_spacer_material_name(name, material_name)
        duration = volume / minimum
        cumulative += duration
        result[name] = {
            "name": name, "material_name": "" if material_name is None else str(material_name),
            "volume": volume, "density": density, "effective_density": effective,
            "pump_rate": rate, "min_rate": minimum, "duration_min": duration,
            "duration_str": format_to_hr_mm(duration), "cumul_time_min": cumulative,
            "cumul_time_str": format_to_hr_mm(cumulative),
        }
    if state.get("job_type") == materials_db.CT_JOB and old.get("Main") != result.get("Main"):
        state.pop("cement_note_Main", None)
        invalidate_document(state)
    state["fluid_data"] = result
    state["total_pump_time_min"] = cumulative
    state["total_pump_time_hhmm"] = format_to_hr_mm(cumulative)


def refresh_preflush(state):
    if "Pre Flush" not in state.get("fluids_config", {}).get("active", []):
        state["preflush_calc"] = None
        return []
    cfg = state.get("preflush_config")
    if not isinstance(cfg, dict):
        return ["Pre Flush: open Phase VI to review the formulation before export."]
    kind = cfg.get("type")
    kind = {"Chemical Wash": "Water + Chemical Wash", "Combined / Custom": "Combined (Water + NaCl + Wash)"}.get(kind, kind)
    if kind not in {"Fresh Water Only", "Water + Chemical Wash", "Brine (Water + NaCl)", "Combined (Water + NaCl + Wash)"}:
        return ["Pre Flush: review the fluid type in Phase VI before export."]
    info = state["fluid_data"]["Pre Flush"]
    volume = float(info["volume"])
    salt = float(cfg.get("nacl_multiplier", 126.0)) if kind in {"Brine (Water + NaCl)", "Combined (Water + NaCl + Wash)"} else 0.0
    wash = float(cfg.get("wash_multiplier", 3.0)) if kind in {"Water + Chemical Wash", "Combined (Water + NaCl + Wash)"} else 0.0
    state["preflush_calc"] = {
        "type": kind, "volume_bbl": volume, "density_pcf": info["density"],
        "effective_density": info["effective_density"], "water_bbl": round_half_up(volume, 1),
        "nacl_multiplier": salt, "wash_multiplier": wash,
        "nacl_lbs": round_half_up(volume * salt, 1), "wash_gal": round_half_up(volume * wash, 1),
    }
    return []


def phase7_lab_fluids(state):
    """Phase-VII admission only; A3 hydraulic source routing remains unchanged."""
    return [fluid for fluid in state.get("fluids_config", {}).get("active", [])
            if fluid in (*materials_db.PHASE7_LAB_FLUIDS, "Spacer")
            and fluid in available_fluid_types(state)]


def spacer_lab_grid(state):
    """Rebuild every computed cell; retain only Lot No. by ingredient identity."""
    from standalone_spacer import formulation_from_state, lab_sample
    grid = pd.DataFrame(lab_sample(formulation_from_state(state))["rows"])
    previous = state.get("lab_grid_dfs", {}).get("Spacer")
    lots = (dict(zip(previous["Material"], previous["Lot No"]))
            if isinstance(previous, pd.DataFrame) and {"Material", "Lot No"}.issubset(previous.columns) else {})
    lots = {material: "" if lot is None else lot for material, lot in lots.items()}
    grid["Lot No"] = grid["Material"].map(
        lambda material: lots[material] if material in lots else ("Lab Sample" if material == "Fresh Water" else ""))
    # Display precision only; the solver and unrounded lab sample stay intact.
    for column in ("Concentration", "Mass"):
        grid[column] = grid[column].map(lambda value: f"{value:.12g}")
    return grid


def _spacer_lab_source(state):
    from standalone_spacer import formulation_from_state
    recipe = formulation_from_state(state)
    well = state.get("well_data", {})
    # Solo composition is fixed by mode/density. Mix additionally depends on
    # the solved solids per target bbl, including inventory/Dead Volume effects.
    # Never use rounded table cells as the review's source authority.
    defoamer = next(row for row in recipe["materials"] if row["name"] == "Defoamer")
    composition = {"mode": recipe["mode"], "density_pcf": recipe["density_pcf"],
                   "defoamer": {"dose": defoamer["dose"], "basis": defoamer["basis"]}}
    if recipe["mode"] == "Limestone + Barite":
        composition["solids_lb_per_bbl"] = {name: mass / recipe["volume_bbl"]
                                          for name, mass in recipe["solids_lb"].items()}
    return fingerprint({"composition": composition,
                        "bhct": well.get("bhct", state.get("bhct")),
                        "bhst": well.get("bhst", state.get("bhst"))})


def refresh_spacer_lab(state):
    """One rebuild boundary for UI, readiness and restored/cached lab input."""
    try:
        grid = spacer_lab_grid(state)
    except ValueError:
        state.pop("lab_payload_Spacer", None)
        state.get("lab_source_signatures", {}).pop("Spacer", None)
        qc = state.get("lab_qc_params", {}).get("Spacer")
        if isinstance(qc, dict):
            qc["reviewed"] = False
        invalidate_document(state)
        raise
    signature = _spacer_lab_source(state)
    signatures = state.setdefault("lab_source_signatures", {})
    qc = state.setdefault("lab_qc_params", {}).setdefault("Spacer", {})
    previous = state.setdefault("lab_grid_dfs", {}).get("Spacer")
    if (signatures.get("Spacer") != signature
            or not isinstance(previous, pd.DataFrame) or not previous.equals(grid)):
        qc["reviewed"] = False
        state.pop("lab_payload_Spacer", None)
        state["_lab_grid_revision_Spacer"] = state.get("_lab_grid_revision_Spacer", 0) + 1
        invalidate_document(state)
    state["lab_grid_dfs"]["Spacer"] = grid
    signatures["Spacer"] = signature
    return grid


def spacer_lab_payload(state, *, rebuild=True):
    """Only a current cup and explicitly confirmed measured rheology are ready."""
    grid = refresh_spacer_lab(state) if rebuild else spacer_lab_grid(state)
    qc = state.get("lab_qc_params", {}).get("Spacer", {})
    if (state.get("lab_source_signatures", {}).get("Spacer") != _spacer_lab_source(state)
            or not isinstance(state.get("lab_grid_dfs", {}).get("Spacer"), pd.DataFrame)
            or not state["lab_grid_dfs"]["Spacer"].equals(grid)):
        raise ValueError("Review the current Spacer formulation in Phase VII")
    rheology = validate_lab_rheology(qc, "Spacer")
    well = state.get("well_data", {})
    bhct, bhst = well.get("bhct", state.get("bhct")), well.get("bhst", state.get("bhst"))
    if not lab_temperature_valid(bhct, bhst):
        raise ValueError("Review BHCT/BHST in Phase II & III")
    if not qc.get("reviewed", False) or qc.get("review_signature") != lab_review_signature(qc, grid):
        raise ValueError("Confirm measured Spacer lab results for the current formulation")
    return {"grid": grid, "rheology": rheology, "bhct": bhct, "bhst": bhst}


def lab_source_signature(state, slurry):
    if slurry == "Spacer":
        return _spacer_lab_source(state)
    p = state.get("cement_params", {}).get(slurry, {})
    fluid = state.get("fluid_data", {}).get(slurry, {})
    # Cup masses do not depend on field volume, tank or manual field water.
    well = state.get("well_data", {})
    source = {"schema": 3, "material_property_schema": state.get("material_property_schema", 0),
                        "base_cement": p.get("base_cement", "Cement G Delijan"),
                        "cmt_sg": resolve_cement_sg(p),
                        "density": fluid.get("density", "118.0"),
                        "effective_density": fluid.get("effective_density"),
                        "bhst": well.get("bhst", state.get("bhst", "-")), "bhsp": well.get("bhsp", ""),
                        "bhct": well.get("bhct", state.get("bhct")),
                        "additives": state.get("cement_additives_dfs", {}).get(slurry, pd.DataFrame())}
    additives = source["additives"]
    if isinstance(additives, pd.DataFrame) and any(
            is_salt_additive(row.get("Material Type", ""), row.get("Name", ""))
            and safe_float(row.get("User Input"), 0.0) > 0.0
            for _, row in additives.iterrows()):
        source["salt_model_version"] = SALT_MODEL_VERSION
    return fingerprint(source)


def refresh_lab_payloads(state):
    issues = []
    for slurry in state.get("fluids_config", {}).get("active", []):
        if slurry == "Spacer":
            try:
                state["lab_payload_Spacer"] = spacer_lab_payload(state)
            except ValueError as exc:
                state.pop("lab_payload_Spacer", None)
                issues.append(f"Spacer: Phase VII {exc}.")
            continue
        if slurry not in materials_db.RHEOLOGY_LAB_FLUIDS:
            continue
        full_lab = slurry in materials_db.PLACEMENT_SLURRIES
        grid = state.get("lab_grid_dfs", {}).get(slurry)
        qc = state.get("lab_qc_params", {}).get(slurry)
        has_old_data = grid is not None or f"lab_payload_{slurry}" in state
        if not has_old_data:
            issues.append(f"{slurry}: open Phase VII to enter and review the internal Lab/Rheology data.")
            continue
        if (not isinstance(grid, pd.DataFrame) or (full_lab and grid.empty) or not isinstance(qc, dict)
                or state.get("lab_source_signatures", {}).get(slurry) != lab_source_signature(state, slurry)):
            state.pop(f"lab_payload_{slurry}", None)
            issues.append(f"{slurry}: review Phase VII; the lab data has not been checked against the current formulation and well conditions.")
            continue
        required = ("Material", "Concentration", "Unit", "Mass")
        incomplete_row = False
        for row_number, (_, row) in enumerate(grid.iterrows(), start=1):
            def missing(field):
                value = row.get(field)
                return pd.isna(value) or str(value).strip().lower() in {"", "none", "nan", "<na>"}
            if any(not missing(field) for field in (*required, "Lot No")) and any(missing(field) for field in required):
                issues.append(f"{slurry}: Phase VII lab row {row_number} is incomplete; enter Material, Concentration, Unit and Mass, or delete the row before Word export.")
                incomplete_row = True
                break
        if incomplete_row:
            state.pop(f"lab_payload_{slurry}", None)
            continue
        try:
            validate_lab_masses(grid)
            rheology = validate_lab_rheology(qc, slurry)
        except ValueError as exc:
            state.pop(f"lab_payload_{slurry}", None)
            issues.append(f"{slurry}: Phase VII {exc}; correct the Lab/Rheology data before Word export.")
            continue
        extra = {}
        if full_lab:
            try:
                validate_lab_collection_results(qc)
            except ValueError as exc:
                state.pop(f"lab_payload_{slurry}", None)
                issues.append(f"{slurry}: Phase VII {exc}; review both Free Water measurements and Surface Sample Hours before Word export.")
                continue
            try:
                thickening = validate_thickening_test(qc)
            except ValueError as exc:
                state.pop(f"lab_payload_{slurry}", None)
                issues.append(f"{slurry}: Phase VII Thickening Time Test: {exc}.")
                continue
            try:
                compressive = validate_compressive_test(qc)
            except ValueError as exc:
                state.pop(f"lab_payload_{slurry}", None)
                issues.append(f"{slurry}: Phase VII {exc}.")
                continue
            api_fl = qc.get("api_fl", 0.0)
            if isinstance(api_fl, bool) or not isinstance(api_fl, (int, float)) or not math.isfinite(api_fl):
                state.pop(f"lab_payload_{slurry}", None)
                issues.append(f"{slurry}: Phase VII api_fl must be a finite numeric value; review the lab QC input.")
                continue
            extra = {"api_fl": api_fl * 2.0, "api_fl_collected": api_fl,
                     "free_water": qc.get("free_water", "-"), "compressive": compressive,
                     "free_water_45": qc["free_water_45"], "surface_hardened_hours": qc["surface_hardened_hours"],
                     **thickening}
        if (not qc.get("reviewed", False)
              or qc.get("review_signature") != lab_review_signature(qc, grid)):
            state.pop(f"lab_payload_{slurry}", None)
            issues.append(f"{slurry}: Phase VII internal lab results must be confirmed before Word export.")
            continue
        p = state.get("cement_params", {}).get(slurry, {})
        well = state.get("well_data", {})
        bhct = well.get("bhct", state.get("bhct"))
        bhst = well.get("bhst", state.get("bhst"))
        if not lab_temperature_valid(bhct, bhst):
            state.pop(f"lab_payload_{slurry}", None)
            issues.append(f"{slurry}: Phase II & III BHCT and BHST must be finite, with BHCT <= BHST, before Lab review/export.")
            continue
        state[f"lab_payload_{slurry}"] = {
            "grid": grid, "rheology": rheology, "bhct": bhct, "bhst": bhst,
            "bhsp": well.get("bhsp", ""), "base_fluid": p.get("base_fluid_gal_sk", ""),
            "mix_water": p.get("mix_water_gal_sk", ""), "mix_fluid": p.get("mix_fluid_gal_sk", ""),
            "solution_density": materials_db.SOLUTION_DENSITY_PCF, **extra,
        }
    if issues:
        invalidate_document(state)
    return issues


def prepare_calculations(state):
    from phase_5_cement import refresh_cement_calculations
    from cement_chart_model import chart_readiness, formation_source
    from pumping_simulation import prepare_pumping_simulation, source_signature as pumping_source_signature
    from well_schematic_adapter import prepare_schematic, source_signature as schematic_source_signature
    try:
        well_issues = refresh_well_derived(state)
        migrate_material_properties(state)
        purge_inactive_slurries(state, state.get("fluids_config", {}).get("active", []))
        refresh_fluids(state)
        issues = (["Phase II & III: review pending hardware edits before Word export."]
                  if hardware_draft_pending(state) else [])
        issues += [f"Phase II & III: {issue}" for issue in well_issues]
        issues += refresh_cement_calculations(state)
        issues += refresh_preflush(state)
        if "Spacer" in state.get("fluids_config", {}).get("active", []):
            from standalone_spacer import formulation_from_state
            try:
                formulation_from_state(state)
            except ValueError as exc:
                issues.append(f"Phase VI: {exc}")
        issues += refresh_lab_payloads(state)
        # Dormant Diesel sources are drafts, not current chart/report inputs.
        chart_fluids = deepcopy(state.get("fluids_config", {}))
        if "Diesel" not in chart_fluids.get("active", []):
            chart_fluids.get("params", {}).pop("Diesel", None)
        chart_source = fingerprint({
            "job": state.get("job_type"), "geometry": state.get("well_geometry"),
            "hardware": state.get("hardware_table"), "placement": state.get("placement_config"),
            "fluids": chart_fluids, "cement_placement": {
                name: {key: record.get(key) for key in ("top_mode", "top_depth", "top_job_type", "report_bottom_depth")}
                for name, record in state.get("cement_params", {}).items()
                if name in materials_db.PLACEMENT_SLURRIES},
            "mud_density": state.get("mud_density"),
            "formation_pressure": formation_source(state),
        })
        if state.get("_cement_chart_source") != chart_source:
            invalidate_document(state)
        state["_cement_chart_source"] = chart_source
        chart = chart_readiness(state, include_fluids=True)
        state["_cement_chart_model"] = chart["model"]
        state["_cement_chart_warnings"] = chart["warnings"]
        issues += [f"Cementing chart: {issue}" for issue in chart["issues"]]
        try:
            prepare_pumping_simulation(state)
            pumping_source = pumping_source_signature(state)
            if state.get("_pumping_simulation_source") != pumping_source:
                invalidate_document(state)
            state["_pumping_simulation_source"] = pumping_source
        except (ValueError, TypeError, KeyError, ZeroDivisionError, OverflowError) as exc:
            issues.append(f"Pumping Simulation: {exc}")
        try:
            prepare_schematic(state)
            schematic_source = schematic_source_signature(state)
            if state.get("_well_schematic_source") != schematic_source:
                invalidate_document(state)
            state["_well_schematic_source"] = schematic_source
        except (ValueError, TypeError, KeyError, OverflowError) as exc:
            if state.get("job_type") == materials_db.CT_JOB:
                state.pop("_well_schematic_source", None)
            issues.append(f"Phase II & III Well schematic: {exc}")
        if state.get("job_type") == materials_db.CT_JOB:
            from ct_stages import ct_stage_projection
            from engineering_tools import compute_phase_status
            # One placement/depth authority (the B3 schematic admission above)
            # and one report-only stage authority. Missing history is advisory.
            projection = ct_stage_projection(state)
            if projection is not None and projection["tank_name"] not in materials_db.get_available_tanks(materials_db.CT_JOB):
                issues.append("Phase V CT Main: select a Mixing Tank from the existing job catalog.")
            status = compute_phase_status(state)
            for key, label in (("phase2_3", "II & III"), ("phase4", "IV"),
                               ("phase5", "V"), ("phase7", "VII")):
                if status[key]["level"] != "ok":
                    issues.append(f"Phase {label}: {status[key]['message']}")
            if any(name in state.get("fluids_config", {}).get("active", [])
                   for name in ("Pre Flush", "Spacer")) and status["phase6"]["level"] != "ok":
                issues.append(f"Phase VI: {status['phase6']['message']}")
        md, tvd = safe_float(state.get("geo_md"), None), safe_float(state.get("geo_tvd"), None)
        if md is None or tvd is None or not math.isfinite(md) or not math.isfinite(tvd):
            issues.append("Phase II & III: MD and TVD must be valid depths before Word export.")
        elif tvd > md:
            issues.append(f"Phase II & III: TVD ({tvd:g} m) cannot exceed MD ({md:g} m); correct the depth before Word export.")
    except (ValueError, TypeError, KeyError, ZeroDivisionError, OverflowError) as exc:
        issues = [f"Review the current calculation inputs before export ({exc})."]
    if issues:
        invalidate_document(state)
    return issues


def sync_report_text(state, key, generated, signature):
    """Update untouched auto text; hold manual/legacy text for explicit review."""
    records = state.setdefault("report_text_state", {})
    meta = records.get(key)
    current = state.get(key)
    if current is None or (meta is None and current == generated):
        state[key] = generated
        records[key] = {"generated": generated, "source_signature": signature, "history": []}
        return False
    if meta is None:
        # Existing text from older JSON files may be manually edited.
        meta = {"generated": None, "source_signature": None, "history": []}
        records[key] = meta
    if meta.get("source_signature") != signature:
        if current == meta.get("generated"):
            state[key] = generated
            meta.update(generated=generated, source_signature=signature)
        else:
            return True
    return False


def accept_report_text(state, key, generated, signature, replace=False):
    meta = state.setdefault("report_text_state", {}).setdefault(key, {"history": []})
    if replace:
        current = state.get(key, "")
        if current and current != generated and current != meta.get("generated"):
            history = meta.setdefault("history", [])
            if not history or history[-1] != current:
                history.append(current)
            meta["history"] = history[-5:]
        state[key] = generated
    meta.update(generated=generated, source_signature=signature)


def restore_previous_text(state, key):
    meta = state.get("report_text_state", {}).get(key, {})
    history = meta.get("history", [])
    if history:
        state[key] = history.pop()
        meta["source_signature"] = None
