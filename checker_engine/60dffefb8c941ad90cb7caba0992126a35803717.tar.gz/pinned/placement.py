"""Explicit source selection for operational depths and tie-back host."""
import math
import re
import pandas as pd
from project_state import fingerprint
from engineering_tools import require_nonnegative_number

_MD = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*(?:[-–]\s*(\d+(?:\.\d+)?)\s*)?$")
HOST_DESCRIPTIONS = {"Previous Casing", "Casing", "Previous Liner", "Liner"}
EXCESS_FIELDS = (("excess_csg_oh_pct", "Excess CSG-OH %", "excess_oh"),
                ("excess_csg_csg_pct", "Excess CSG-CSG %", "excess_csg"))


def excess_percentage(config, field):
    """Optional percentage points; zero is supplied, None is not supplied."""
    value = config.get(field)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"placement_config.{field} must be a finite nonnegative number or null.")
    return require_nonnegative_number(value, f"placement_config.{field}")


def measured_depth(value):
    """Return the deeper end of a valid MD interval, never a guessed number."""
    match = _MD.fullmatch(str(value))
    if not match:
        return None
    depth = max(float(x) for x in match.groups() if x is not None)
    return depth if math.isfinite(depth) and depth > 0 else None


def ct_setting_depth(table):
    """The single CT Hardware MD authority; optional dimensions are never inferred."""
    from engineering_tools import parse_fractional_size
    if not isinstance(table, pd.DataFrame) or "Description" not in table:
        raise ValueError("CT Setting Depth: add exactly one CT Hardware row with a positive scalar MD (m).")
    rows = table[table["Description"].eq("CT")]
    if len(rows) != 1:
        raise ValueError("CT Setting Depth: exactly one CT Hardware row is required; missing or duplicate CT rows are not resolved automatically.")
    row = rows.iloc[0]
    raw = row.get("MD (m)")
    try:
        if pd.api.types.is_bool(raw):
            raise ValueError
        depth = float(raw)
    except (ValueError, TypeError, OverflowError):
        raise ValueError("CT Setting Depth: MD (m) must be one positive finite scalar, not an interval.") from None
    if not math.isfinite(depth) or depth <= 0:
        raise ValueError("CT Setting Depth: MD (m) must be one positive finite scalar.")
    supplied = {}
    for field in ("Size (in)", "ID (in)", "Joint (m)", "Weight (ppf)", "Collapse (psi)", "Burst (psi)"):
        raw = row.get(field)
        if raw is None or (not isinstance(raw, (list, dict)) and pd.isna(raw)) or raw == "":
            continue
        if pd.api.types.is_bool(raw) or isinstance(raw, (list, dict)):
            raise ValueError(f"CT Hardware {field} must be a finite nonnegative measurement when supplied.")
        try:
            value = parse_fractional_size(str(raw)) if field == "Size (in)" else float(raw)
        except (ValueError, TypeError, OverflowError):
            value = float("nan")
        if not math.isfinite(value) or value < 0 or (field == "Size (in)" and value == 0 and pd.to_numeric(raw, errors="coerce") != 0):
            raise ValueError(f"CT Hardware {field} must be a finite nonnegative measurement when supplied.")
        if value > 0:  # An editor default zero is not measured geometry.
            supplied[field] = value
    if ("Size (in)" in supplied and "ID (in)" in supplied
            and supplied["ID (in)"] >= supplied["Size (in)"]):
        raise ValueError("CT Hardware ID (in) must be smaller than Size (in).")
    return depth


def target_descriptions(job_type):
    if job_type == "CMT PLUG WITH CT":
        return {"CT"}
    name = str(job_type).upper()
    if "TIE BACK" in name:
        return {"Tie Back"}
    if "LNR" in name:
        return {"Liner"}
    if "PLUG" in name or "SQUEEZE" in name:
        return {"Casing", "Liner", "Tie Back", "Open Hole Size"}
    return {"Casing"}


def hardware_choices(table, descriptions):
    if not isinstance(table, pd.DataFrame) or table.empty:
        return {}
    choices = {}
    for _, row in table.iterrows():
        desc = str(row.get("Description", "")).strip()
        depth = measured_depth(row.get("MD (m)"))
        if desc not in descriptions or depth is None:
            continue
        size = str(row.get("Size (in)", "")).strip()
        token = fingerprint([desc, str(row.get("MD (m)")).strip(), size])
        choices[token] = {"description": desc, "depth": depth, "size": size,
                          "label": f"{desc} | {size or 'size not set'} in | {row.get('MD (m)')} m MD"}
    return choices


def target_depth(table, job_type, config):
    if job_type == "CMT PLUG WITH CT":
        return ct_setting_depth(table)
    if config.get("job_type") != job_type:
        return None
    if config.get("target_row") == "__manual__":
        return measured_depth(config.get("manual_depth_m"))
    return hardware_choices(table, target_descriptions(job_type)).get(config.get("target_row"), {}).get("depth")


def host_label(table, job_type, config):
    if config.get("job_type") != job_type:
        return None
    row = hardware_choices(table, HOST_DESCRIPTIONS).get(config.get("host_row"))
    if not row or not row["size"]:
        return None
    kind = "Casing" if "Casing" in row["description"] else "Liner"
    return f'{row["size"]}" {kind}'


def top_label(params, job_type=None, target=None):
    if job_type is not None and params.get("top_job_type") not in (None, job_type):
        return ".... m [TOP NOT SET IN PHASE V]", None
    mode = params.get("top_mode")
    text, depth = ".... m [TOP NOT SET IN PHASE V]", None
    if mode == "Surface":
        text, depth = "surface", 0.0
    elif mode == "Depth (m MD)" or (mode is None and params.get("top_depth") not in (None, "", 0)):
        try:
            require_nonnegative_number(params.get("top_depth"), "Top depth")
        except ValueError:
            return text, None
        depth = measured_depth(params.get("top_depth"))
        if depth is not None:
            text = f"{depth:.1f} m"
    if target is not None and depth is not None and depth >= target:
        return f".... m [TOP MUST BE ABOVE TARGET DEPTH {target:.1f} m MD]", None
    return text, depth


def slurry_intervals(table, job_type, config, active_slurries, cement_params, fluid_data=None):
    """One engineering projection; Plug/Squeeze retain their independent tops.

    Incomplete report contexts keep explicit missing values. Normal readiness
    and export use the same resolver and block its controlled issues.
    """
    from cement_chart_model import chart_job_kind, resolve_cement_placement
    try:
        rows = None
        if chart_job_kind(job_type) is not None:
            state = {"job_type": job_type, "hardware_table": table, "placement_config": config,
                     "fluids_config": {"active": active_slurries, "params": fluid_data or {}}}
            rows = resolve_cement_placement(state)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        return {name: {"top": ".... m [PLACEMENT INCOMPLETE]", "top_depth": None,
                       "bottom": ".... m [PLACEMENT INCOMPLETE]", "bottom_depth": None,
                       "issue": str(exc)} for name in reversed(active_slurries)}
    if rows is not None:
        return {row["fluid"]: {"top": "surface" if row["top_md"] == 0 else f"{row['top_md']:.1f} m",
                              "top_depth": row["top_md"], "bottom": f"{row['bottom_md']:.1f} m MD",
                              "bottom_depth": row["bottom_md"], "returned_bbl": row["returned_bbl"]}
                for row in rows}
    try:
        target = target_depth(table, job_type, config)
    except ValueError as exc:
        return {name: {"top": ".... m [PLACEMENT INCOMPLETE]", "top_depth": None,
                       "bottom": ".... m [PLACEMENT INCOMPLETE]", "bottom_depth": None,
                       "issue": str(exc)} for name in active_slurries}
    target_text = (f"{target:.1f} m MD" if target is not None
                   else ".... m MD [TARGET DEPTH NOT SELECTED IN PHASE II/III]")
    job = str(job_type).upper()
    chained = "CSG" in job or ("LNR" in job and "TIE BACK" not in job)
    bottom_text, bottom_depth = target_text, target
    intervals = {}
    for slurry in reversed(active_slurries) if chained else active_slurries:
        top, depth = top_label(cement_params.get(slurry, {}), job_type, target)
        if chained and bottom_depth is not None and depth is not None and depth >= bottom_depth:
            top, depth = f".... m [TOP MUST BE ABOVE PREVIOUS INTERVAL {bottom_depth:.1f} m MD]", None
        intervals[slurry] = {"top": top, "top_depth": depth,
                             "bottom": bottom_text, "bottom_depth": bottom_depth}
        if chained:
            bottom_text, bottom_depth = top, depth
    return intervals

# Report metadata only: none of these values participates in placement calculations.
SUMMARY_VERSION = 1
VOLUME_BASES = ("auto", "unspecified", "excess", "client_request", "direct")
TIE_BACK_ORIGINS = ("Target depth", "Tie Back Sleeve", "Shoe")
SQUEEZE_SCOPES = ("", "Liner", "Liner Lap", "Casing Region")
SUMMARY_SLURRIES = ("Lead", "Lead #1", "Lead #2", "Main", "Tail")
SUMMARY_NUMBERS = ("excess_csg_oh_pct", "excess_csg_csg_pct", "wet_stands", "liner_lap_m")
SUMMARY_TOKENS = ("wet_inside_host_row", "liner_lap_host_row")


def validate_executive_summary_config(config):
    """Validate report drafts without requiring optional facts to be supplied."""
    import materials_db
    if not isinstance(config, dict):
        raise ValueError("executive_summary_config must be a record.")
    allowed = {"version", "job_type", "placement_context_rows", "squeeze_scope",
               "squeeze_context_row", "tie_back_origin", "per_slurry"}
    if set(config) - allowed:
        raise ValueError("executive_summary_config contains unsupported fields.")
    if type(config.get("version")) is not int or config["version"] != SUMMARY_VERSION:
        raise ValueError("executive_summary_config has an unsupported version.")
    if config.get("job_type") not in materials_db.JOB_TYPES:
        raise ValueError("executive_summary_config.job_type is not supported.")
    for field, options in (("squeeze_scope", SQUEEZE_SCOPES), ("tie_back_origin", TIE_BACK_ORIGINS)):
        if field in config and (not isinstance(config[field], str) or config[field] not in options):
            raise ValueError(f"executive_summary_config.{field} is not supported.")
    contexts = config.get("placement_context_rows", [])
    if not isinstance(contexts, list) or any(not isinstance(token, str) for token in contexts):
        raise ValueError("executive_summary_config.placement_context_rows must contain string tokens.")
    if "squeeze_context_row" in config and not isinstance(config["squeeze_context_row"], str):
        raise ValueError("executive_summary_config.squeeze_context_row must be a string token.")
    per_slurry = config.get("per_slurry", {})
    if not isinstance(per_slurry, dict):
        raise ValueError("executive_summary_config.per_slurry must be a record.")
    for slurry, record in per_slurry.items():
        if slurry not in SUMMARY_SLURRIES or not isinstance(record, dict):
            raise ValueError("executive_summary_config.per_slurry contains an invalid slurry record.")
        if set(record) - {"volume_basis", *SUMMARY_NUMBERS, *SUMMARY_TOKENS}:
            raise ValueError(f"executive_summary_config.per_slurry.{slurry} contains unsupported fields.")
        if "volume_basis" in record and (not isinstance(record["volume_basis"], str)
                                        or record["volume_basis"] not in VOLUME_BASES):
            raise ValueError(f"executive_summary_config.per_slurry.{slurry}.volume_basis is not supported.")
        for field in SUMMARY_NUMBERS:
            excess_percentage(record, field)
        for field in SUMMARY_TOKENS:
            if field in record and not isinstance(record[field], str):
                raise ValueError(f"executive_summary_config.per_slurry.{slurry}.{field} must be a string token.")
    return config


def summary_config_for_job(config, job_type, active_slurries):
    """Ignore another job's metadata and inactive drafts in generation/signatures."""
    if config is None:
        return {}
    validate_executive_summary_config(config)
    if config["job_type"] != job_type:
        return {}
    records = {name: record for name, record in config.get("per_slurry", {}).items()
               if name in active_slurries}
    effective = {key: value for key, value in config.items() if key != "per_slurry"}
    if records:
        effective["per_slurry"] = records
    return effective if set(effective) - {"version", "job_type"} else {}


def resolve_report_excess(job_type, placement_config, summary_config, slurry):
    """One report-only override/global/absent authority for Summary and Word."""
    config = summary_config_for_job(summary_config, job_type, [slurry])
    overrides = config.get("per_slurry", {}).get(slurry, {})
    global_values = placement_config if placement_config.get("job_type") == job_type else {}
    return {report_key: (excess_percentage(overrides, field)
                         if overrides.get(field) is not None else excess_percentage(global_values, field))
            for field, _, report_key in EXCESS_FIELDS}


def hardware_row_metadata(table, token):
    """Resolve current labels through the existing stable hardware token model."""
    return hardware_choices(table, HOST_DESCRIPTIONS | {"Open Hole Size", "Tie Back"}).get(token)


def target_row_metadata(table, job_type, config):
    if config.get("job_type") != job_type:
        return None
    return hardware_choices(table, target_descriptions(job_type)).get(config.get("target_row"))


def hardware_context_label(table, token):
    row = hardware_row_metadata(table, token)
    if not row:
        return None
    kind = ("Open Hole" if row["description"] == "Open Hole Size" else
            "Casing" if "Casing" in row["description"] else
            "Liner" if "Liner" in row["description"] else "Tie Back")
    return f'{row["size"]}" {kind}' if row["size"] else kind
