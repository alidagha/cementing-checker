"""Regression checks for project restoration, defaults and Word export.

Run from the repository root with: python -m unittest discover -s tests -v
"""
import ast
from datetime import date, datetime
from copy import deepcopy
from io import BytesIO
import json
import math
import re
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import pandas as pd
from docx import Document
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import materials_db
from engineering_tools import compute_phase_status, lab_review_signature, round_half_up, BBL_TO_CUFT, WORD_ADVISORY_PHASES
from project_io import decode_project
from project_state import is_project_key, prepare_calculations, hardware_draft_pending
from centralizer_fixtures import ensure_current_centralizer
from placement import hardware_choices, target_descriptions, HOST_DESCRIPTIONS

# Use the application's serializers without running its top-level UI.
tree = ast.parse((ROOT / "main.py").read_text())
namespace = {"pd": pd, "date": date, "datetime": datetime, "math": math}
exec(compile(ast.Module(body=[node for node in tree.body
                             if isinstance(node, ast.FunctionDef)
                             and node.name in ("serialize_item", "deserialize_item")],
                        type_ignores=[]), str(ROOT / "main.py"), "exec"), namespace)


def round_trip(state):
    saved = {key: namespace["serialize_item"](value)
             for key, value in state.items() if is_project_key(key)}
    return decode_project(json.dumps(saved, allow_nan=False).encode(),
                          namespace["deserialize_item"])


def well_profile_fixture(md=3000.0, tvd=None, bhst=200.0, gradient=None):
    """Explicit Round 7A canonical prerequisites for existing test scenarios."""
    tvd = md if tvd is None else tvd
    geometry = {"version": 1, "type": "Vertical", "td_m": md}
    if md != tvd:
        deviation = math.degrees(math.acos(tvd / md))
        geometry = {"version": 1, "type": "Directional", "survey": pd.DataFrame(
            [[0., deviation, 0.], [md, deviation, 0.]], columns=["MD", "Deviation", "Azimuth"])}
    return {"well_geometry": geometry, "geothermal_config": {"version": 1,
            "source": "BHST" if gradient is None else "Temperature Gradient",
            "surface_temp": 80.0, "value": bhst if gradient is None else gradient}}


def chart_fixture(job, target=3000.0):
    """Explicit Round 8A Hardware/input prerequisites, never production defaults."""
    casing = {
        'CSG 30"': (30., 28., 36., 34.), 'CSG 24"': (24., 22., 30., 28.),
        'CSG 20"': (20., 18., 26., 24.), 'CSG 18 5/8"': (18.625, 17., 24., 22.),
        'CSG 13 3/8"': (13.375, 12.25, 20., 18.),
        'CSG 9 5/8"': (9.625, 8.535, 13.375, 12.25), 'CSG 7"': (7., 6.276, 9.625, 8.535),
    }
    liner = {'LNR 7"': (7., 6.276), 'LNR 5"': (5., 4.276), 'LNR 4 1/2"': (4.5, 4.)}
    tieback = {'TIE BACK LNR 7"': (7., 6.276), 'TIE BACK LNR 5"': (5., 4.276)}
    extent = max(3300., target)
    if job in casing:
        od, inner, outer_od, outer_id = casing[job]
        rows = [("Previous Casing", 1500., outer_od, outer_id),
                ("Casing", extent, od, inner), ("Open Hole Size", extent, outer_id, outer_id)]
    elif job == 'LNR 4 1/2"':
        rows = [("Previous Casing", 1500., 7., 6.276),
                ("Liner", target, 4.5, 4.), ("Open Hole Size", extent, 6., 6.),
                ("Liner Hanger", 1000., 4.5, 4.), ("Drill Pipes", 1000., 3.5, 2.75)]
    elif job in liner:
        od, inner = liner[job]
        rows = [("Previous Casing", 1500., 13.375, 12.25),
                ("Liner", extent, od, inner), ("Open Hole Size", extent, 12.25, 12.25),
                ("Liner Hanger", 1000., 9.625, 8.535), ("Drill Pipes", 1000., 5., 4.276)]
    elif job in tieback:
        # Synthetic scalar-certification well: receiver starts at the tie-in.
        # It is NOT equivalent to the old 2500-m Top / two-ID receiving liner.
        od, inner = tieback[job]
        extent = max(extent, target + 300.)
        rows = [("Previous Casing", extent, 13.375, 12.25), ("Tie Back", f"0-{target}", od, inner),
                ("Previous Liner", f"{target}-{extent}", 9.625, 8.535)]
    else:
        rows = [("Previous Casing", target, 20., 18.)]
    table = pd.DataFrame([{"Description": desc, "MD (m)": str(md), "Size (in)": str(size),
                          "ID (in)": inner, "Joint (m)": 12., "Weight (ppf)": 100.,
                          "Grade": "K-55", "Collapse (psi)": 1000., "Burst (psi)": 2000.}
                         for desc, md, size, inner in rows])
    target_row = next(iter(hardware_choices(table, {"Liner"}))) if job == 'LNR 4 1/2"' else "__manual__"
    return {"hardware_table": table, "pore_gradient_emw_pcf": 70., "frac_gradient_emw_pcf": 160.,
            "placement_config": {"job_type": job, "target_row": target_row, "manual_depth_m": target,
                                 **({"chart_excess_mode": "ignore"} if job in casing or job in liner or job in tieback else {})}}


def rheology_fixture():
    """Measured Rheology prerequisite for existing valid-export fixtures."""
    return {"surface_down": {"selected": True,
            "readings": dict(zip(('300', '200', '100', '60', '30', '6', '3'),
                                 ('168', '116', '64', '41', '24', '8', '6'))),
            "gel_10_sec": "8", "gel_10_min": "12"}}


def valid_export_chart_fixture(job, target=3000.0):
    """Explicit Hardware selection for valid Pumping exports; manual drafts stay separate."""
    fixture = chart_fixture(job, target)
    if job in ('CMT PLUG', 'CMT SQUEEZE'):
        return fixture
    table = fixture['hardware_table']
    descriptions = target_descriptions(job)
    table.loc[table['Description'].isin(descriptions), 'MD (m)'] = str(target)
    if 'TIE BACK' in job:
        table.loc[table['Description'] == 'Tie Back', 'MD (m)'] = f'0-{target}'
        fixture['placement_config']['host_row'] = next(token for token, row in
            hardware_choices(table, HOST_DESCRIPTIONS).items() if row['description'] == 'Previous Casing')
    fixture['placement_config']['target_row'] = next(iter(hardware_choices(table, descriptions)))
    return fixture


def valid_export_rheology_fixture():
    """Independent measured BHCT-down prerequisite, preserving surface-down inputs."""
    return {**rheology_fixture(), 'bhct_down': {'selected': True,
        'readings': dict(zip(('300', '200', '100', '60', '30', '6', '3'),
                             ('168', '116', '64', '41', '24', '8', '6'))),
        'gel_10_sec': '8', 'gel_10_min': '12'}}


def thickening_fixture():
    """Explicit measured Round 5-2 inputs for existing valid-export fixtures."""
    return {"thickening_test_start": "08:00", "thickening_enter_time": "00:00",
            "thickening_cell": 1.0, "thickening_30_bc": "01:00", "thickening_50_bc": "02:00"}


def compressive_fixture():
    """Explicit measured Round 5-3 prerequisite; no production default."""
    return {"compressive": {"crush": {"selected": True,
            "force_1": 400.0, "force_2": 401.0, "force_3": 402.0, "force_4": 403.0}}}


BATCH1_JOBS = ('CSG 9 5/8"', 'CMT PLUG', 'CMT SQUEEZE', 'LNR 7"', 'TIE BACK LNR 7"')


def configure_standalone_spacer(app, mode="Limestone", dead_vol=0.):
    """Enter a current A1 formulation through its real Phase-VI controls."""
    next(w for w in app.selectbox if w.label == "Weighting Agent Mode").set_value(mode).run()
    next(w for w in app.number_input if w.label == "Dead Volume (bbl) - Spacer").set_value(dead_vol).run()
    assert not app.exception, [e.message for e in app.exception]


class AuditRegressions(unittest.TestCase):
    def app(self, project=None):
        app = AppTest.from_file(str(ROOT / "main.py"), default_timeout=30)
        for key, value in (project or {}).items():
            app.session_state[key] = value
        app.run()
        self.healthy(app)
        return app

    def healthy(self, app):
        self.assertFalse(app.exception, [e.message for e in app.exception])

    def phase(self, app, name):
        app.radio(key="_app_mode_key").set_value(name).run()
        self.healthy(app)
        self.assertEqual(app.radio(key="_app_mode_key").value, name)

    def test_all_pages(self):
        app = self.app()
        for phase in ("phase1", "phase2_3", "phase4", "phase5", "phase6", "phase7", "phase10"):
            with self.subTest(phase=phase):
                self.phase(app, phase)

    def test_hole_size_save_load_and_legacy_defaults(self):
        for hole, customized, expected in (
            ('Custom approved hole', None, 'Custom approved hole'),
            ('26"', None, '12 1/4"'),
            ('26"', True, '26"'),
        ):
            with self.subTest(hole=hole, customized=customized):
                project = {"job_type": 'CSG 20"', "hole_size": hole}
                if customized is not None:
                    project["hole_size_customized"] = customized
                app = self.app(round_trip(project))
                app.selectbox(key="_w_job_type").set_value('CSG 9 5/8"').run()
                self.healthy(app)
                self.assertEqual(next(w for w in app.text_input if w.label == 'Hole Size (in)').value, expected)

        app = self.app()
        next(w for w in app.text_input if w.label == 'Hole Size (in)').set_value('Custom approved hole').run()
        next(w for w in app.text_input if w.label == 'Hole Size (in)').set_value('26"').run()
        restored = round_trip(app.session_state.to_dict())
        self.assertTrue(restored["hole_size_customized"])
        app = self.app(restored)
        app.selectbox(key="_w_job_type").set_value('CSG 9 5/8"').run()
        self.healthy(app)
        self.assertEqual(next(w for w in app.text_input if w.label == 'Hole Size (in)').value, '26"')

    def test_numeric_lab_tables_restore_and_render(self):
        grid = pd.DataFrame([
            {"Material": "CEMENT G DELIJAN", "Concentration": 100.0,
             "Unit": "BWOB", "Mass": 600.0, "Lot No": "sample"},
            {"Material": "Base Water", "Concentration": None,
             "Unit": "BWOW", "Mass": None, "Lot No": None},
        ])
        for archived in (False, True):
            with self.subTest(archived=archived):
                project = {
                    "job_type": 'CSG 20"',
                    "fluids_config": {"active": ["Main"], "params": {
                        "Main": {"volume": 50.0, "density": "118", "pump_rate": "4"}}},
                }
                if archived:
                    project["inactive_slurry_drafts"] = {"Main": {"lab_grid_dfs": grid}}
                else:
                    project["lab_grid_dfs"] = {"Main": grid}
                restored = round_trip(project)
                normalized = (restored["inactive_slurry_drafts"]["Main"]["lab_grid_dfs"]
                              if archived else restored["lab_grid_dfs"]["Main"])
                self.assertEqual(normalized.iloc[0]["Concentration"], "100.0")
                self.assertTrue(pd.isna(normalized.iloc[1]["Concentration"]))
                app = self.app(restored)
                self.phase(app, "phase4")
                self.phase(app, "phase7")
                self.assertIn("Main", app.session_state["lab_grid_dfs"])

    def test_spacer_defaults_and_saved_densities(self):
        spacers = ("Spacer", "Spacer Ahead", "Spacer Behind")
        for params in (None, {}, {s: {"volume": 0.0, "density": "101.0", "pump_rate": "4"}
                                 for s in spacers}):
            with self.subTest(params=params):
                expected = "101.0" if params else "80.0"
                app = self.app(None if params is None else {
                    "job_type": 'CSG 20"',
                    "fluids_config": {"active": list(spacers), "params": params},
                })
                self.phase(app, "phase4")
                if params is None:
                    for name in spacers:
                        app.checkbox(key="chk_fluid_" + name).check().run()
                # This scenario supplies the formerly implicit spacer density explicitly.
                if expected == "80.0":
                    for name in spacers:
                        app.text_input(key="den_" + name).set_value("80.0").run()
                self.healthy(app)
                for name in spacers:
                    self.assertEqual(app.text_input(key="den_" + name).value, expected)

    def configured_app(self, job, additives=False, optional_fluids=False, include_standalone_spacer=True):
        # Valid export fixtures explicitly supply the former well defaults.
        app = self.app({**well_profile_fixture(), "mud_density": "80.0", "plastic_viscosity": "45", "yield_point": "15",
                        "geo_md": 3000.0, "geo_tvd": 3000.0, "bhst": 200, "bhct": 150, "geo_gradient": 1.25,
                        **({"job_type": job, "hole_size": materials_db.DEFAULT_HOLE_SIZES[job]}
                           if job == 'CSG 7"' else {})})
        if job != 'CSG 7"':
            app.selectbox(key="_w_job_type").set_value(job).run()
        app.text_input(key="_w_well_name").set_value("Regression Well").run()
        app.text_input(key="_w_client").set_value("Regression Client").run()
        for key, value in valid_export_chart_fixture(job).items():
            app.session_state[key] = value
        self.phase(app, "phase2_3")
        target = next(w for w in app.selectbox if w.label == "Target shoe / treatment depth source")
        target.set_value(app.session_state['placement_config']['target_row']).run()
        if job in ('CMT PLUG', 'CMT SQUEEZE'):
            next(w for w in app.number_input if w.label == "Measured target depth (m MD)").set_value(3000.0).run()
        if "TIE BACK" in job:
            host = next(w for w in app.selectbox if w.label.startswith("Tie-back host"))
            host.select_index(1).run()
        self.phase(app, "phase4")
        selected = ["Main"]
        if optional_fluids:
            # Keep Standalone coverage available. Legacy export fixtures opt
            # out explicitly when exercising the unchanged generic sibling editors.
            selected += ["Pre Flush"] + (["Spacer"] if include_standalone_spacer else []) + ["Spacer Ahead", "Spacer Behind"]
        for name in selected:
            app.checkbox(key="chk_fluid_" + name).check().run()
        for name in app.session_state["fluids_config"]["active"]:
            app.number_input(key="vol_" + name).set_value(50.0).run()
            # Valid export fixtures supply every operational input explicitly.
            app.text_input(key="rate_" + name).set_value("4.0").run()
            if name != "Displacement Fluid":
                app.text_input(key="den_" + name).set_value("118.0" if name == "Main" else "80.0").run()
        if additives:
            app.session_state["cement_additives_dfs"] = {"Main": pd.DataFrame([
                {"Material Type": "Anti Foam", "Name": "Anti Foam", "Physical State": "Liquid",
                 "Mix Method": "In Mix Water", "User Input": 0.01},
            ])}
        self.phase(app, "phase5")
        # This existing export fixture uses an explicitly measured SG 3.20.
        next(w for w in app.number_input if w.label == "Cement SG - Main").set_value(3.20).run()
        next(w for w in app.number_input if w.label == "Dead Vol (bbl) - Main").set_value(31.0).run()
        next(w for w in app.selectbox if w.label == "Top of cement - Main").set_value("Surface").run()
        if optional_fluids:
            app.session_state["spacer_dfs"] = {s: pd.DataFrame([
                {"Chemical": "Spacer", "User Input (% or gal)": 1.0, "Weighting Agent Type": "-"},
            ]) for s in ("Spacer Ahead", "Spacer Behind")}
        self.phase(app, "phase6")
        if optional_fluids and include_standalone_spacer:
            configure_standalone_spacer(app)
        measured = (rheology_fixture() if job in ('CMT PLUG', 'CMT SQUEEZE')
                    else valid_export_rheology_fixture())
        app.session_state["lab_qc_params"] = {"Main": {"rheology": measured, **thickening_fixture(), **compressive_fixture()}}
        if optional_fluids and include_standalone_spacer:
            app.session_state["lab_qc_params"]["Spacer"] = {"rheology": valid_export_rheology_fixture()}
        self.phase(app, "phase7")
        for label, value in (("Free Water Collected (45° angle) (ml) - Main", 0.0),
                             ("Surface Sample Hours - Main", 8.0)):
            next(w for w in app.number_input if w.label == label).set_value(value).run()
        next(w for w in app.text_input if w.label == "70 Bc (HH:MM) - Main").set_value("03:30").run()
        confirmations = [b.key for b in app.button if b.label == "Confirm measured lab results"]
        for key in confirmations:
            app.button(key=key).click().run()
        ensure_current_centralizer(app.session_state)
        if optional_fluids and job not in ('CMT PLUG', 'CMT SQUEEZE'):
            # These explicit legacy Pre Flush readings also feed Phase VII.
            # N/A jobs do not create config through Centralizer execution.
            if 'centralizer_config' not in app.session_state:
                from phase_9_centralizer import new_config
                app.session_state['centralizer_config'] = new_config()
            app.session_state['centralizer_config']['aux_rheology'] = {
                fluid: dict(zip(('300', '200', '100', '60', '30', '6', '3'),
                                (168., 116., 64., 41., 24., 8., 6.)))
                for fluid in ('Pre Flush', 'Spacer', 'Spacer Ahead', 'Spacer Behind')}
        self.healthy(app)
        return app

    def export(self, app, *, build_timeout=120):
        ensure_current_centralizer(app.session_state)
        self.phase(app, "phase10")
        self.assertFalse(app.error, [e.value for e in app.error])
        build = next(b for b in app.button if b.label == "Build Word Document")
        self.assertFalse(build.disabled)
        # Scope the allowance to Word Build; ordinary widget reruns keep their default.
        build.click().run(timeout=build_timeout)
        self.healthy(app)
        self.assertFalse(app.error, [e.value for e in app.error])
        doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
        self.assertTrue(doc.tables)
        text = "\n".join(cell.text for table in doc.tables for row in table.rows for cell in row.cells)
        self.assertIn("Regression Client", text)

    def test_fractional_liner_fixture_preserves_hardware_and_explicit_excess_gate(self):
        import cement_chart_model as chart
        import centralizer_adapter as centralizer
        job = 'LNR 4 1/2"'
        for factory in (chart_fixture, valid_export_chart_fixture):
            with self.subTest(factory=factory.__name__):
                state = {"job_type": job, **factory(job)}
                config = state["placement_config"]
                self.assertIn(config["target_row"], hardware_choices(state["hardware_table"], {"Liner"}))
                self.assertEqual(config["chart_excess_mode"], "ignore")
                geometry = chart.resolve_chart_geometry(state)
                liner = next(row for row in geometry["active_string"] if row["description"] == "Liner")
                hole = next(row for row in geometry["enclosing_string"] if row["description"] == "Open Hole Size")
                self.assertEqual((liner["od_in"], liner["id_in"], hole["od_in"]), (4.5, 4., 6.))
                config.pop("chart_excess_mode")
                for consumer in (chart.resolve_chart_geometry, centralizer.to_engine_geometry):
                    with self.assertRaisesRegex(ValueError, "Choose Chart Capacity Excess Mode explicitly"):
                        consumer(state)

    def test_neat_cement_export_for_every_job_type(self):
        for job in materials_db.JOB_TYPES:
            with self.subTest(job=job):
                if job == materials_db.CT_JOB:
                    import phase_10_procedure as report
                    app = self.app({"job_type": job, "_compiled_doc_bytes": b"old"})
                    self.phase(app, "phase10")
                    self.assertTrue(any("Phase IV" in w.value
                                        for w in app.warning))
                    self.assertFalse(any(b.label == "Build Word Document" for b in app.button))
                    self.assertFalse(app.get("download_button"))
                    self.assertNotIn("_compiled_doc_bytes", app.session_state)
                    for prepared in (False, True):
                        state = app.session_state.to_dict()
                        state["_compiled_doc_bytes"] = b"old"
                        with patch.object(report.st, 'session_state', state):
                            with self.assertRaisesRegex(ValueError, "Phase IV"):
                                report.build_master_context(calculations_prepared=prepared)
                        self.assertNotIn("_compiled_doc_bytes", state)
                    continue
                app = self.configured_app(job)
                self.assertTrue(app.session_state["cement_additives_dfs"]["Main"].empty)
                self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
                self.export(app)

    def test_additives_optional_fluids_and_saved_project_export(self):
        app = self.configured_app('CSG 20"', additives=True, optional_fluids=True, include_standalone_spacer=False)
        self.export(app)
        app = self.app(round_trip(app.session_state.to_dict()))
        for phase in ("phase2_3", "phase4", "phase5", "phase6", "phase7"):
            self.phase(app, phase)
        self.export(app)
        app.session_state["cement_additives_dfs"]["Main"].loc[0, "User Input"] = None
        self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "warning")
        self.phase(app, "phase10")
        self.assertTrue(next(b for b in app.button if b.label == "Build Word Document").disabled)
        self.assertNotIn("_compiled_doc_bytes", app.session_state)


    def assert_export_blocked(self, app):
        self.phase(app, "phase10")
        self.assertTrue(next(b for b in app.button if b.label == "Build Word Document").disabled)
        for key in ("_compiled_doc_bytes", "_compiled_doc_filename", "_compiled_doc_signature"):
            self.assertNotIn(key, app.session_state)
        self.assertFalse(any(b.proto.label == "Download Final Document (.docx)"
                             for b in app.get("download_button")))
        readiness = next(e for e in app.expander if "Export readiness checklist" in e.label)
        self.assertFalse(readiness.label.startswith("✅"))
        self.assertEqual(len(app.text_area), 2)  # Repairable report editors stay mounted.

    def test_batch1_calculation_errors_block_export(self):
        for job in BATCH1_JOBS:
            with self.subTest(job=job):
                app = self.configured_app(job, optional_fluids=True, include_standalone_spacer=False)
                self.export(app, build_timeout=120)
                app.session_state["preflush_config"]["wash_multiplier"] = "abc"
                # The stale Phase VI cache still looks complete: the calculation
                # failure itself must block export, independently of status.
                self.assertTrue(all(s["level"] == "ok"
                                    for phase, s in compute_phase_status(app.session_state).items()
                                    if phase not in WORD_ADVISORY_PHASES))
                self.assert_export_blocked(app)
                self.assertTrue(app.error)
                self.assertTrue(prepare_calculations(deepcopy(app.session_state.to_dict())))
                self.assertEqual(round_trip(app.session_state.to_dict())["preflush_config"]["wash_multiplier"], "abc")
                self.phase(app, "phase6")
                next(w for w in app.text_input if w.label.startswith("Correct Preflush wash ratio")).set_value("3").run()
                next(b for b in app.button if b.label == "Apply corrected values").click().run()
                self.export(app, build_timeout=120)

    def test_batch1_restored_cement_bounds_block_export(self):
        invalid = (("yield", -1.0), ("yield", 0.0), ("yield", 0.0005),
                   ("mix_water", -1.0), ("dead_vol", -31.0),
                   ("cmt_sg", 2.49), ("cmt_sg", 3.51))
        for job in BATCH1_JOBS:
            valid = self.configured_app(job)
            self.export(valid)
            saved = round_trip(valid.session_state.to_dict())
            compiled = {k: valid.session_state[k] for k in
                        ("_compiled_doc_bytes", "_compiled_doc_filename", "_compiled_doc_signature")}
            for field, value in invalid:
                with self.subTest(job=job, field=field, value=value):
                    project = deepcopy(saved)
                    project["cement_params"]["Main"].update(auto_calc=False)
                    project["cement_params"]["Main"][field] = value
                    app = self.app({**round_trip(project), **compiled})
                    self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "warning")
                    self.assertNotIn("_compiled_doc_bytes", app.session_state)
                    self.assert_export_blocked(app)
                    self.assertTrue(prepare_calculations(deepcopy(app.session_state.to_dict())))
                    self.assertEqual(app.session_state["cement_params"]["Main"][field], value)
                    self.phase(app, "phase5")
                    self.assertTrue(any(w.label.startswith("Correct ") for w in app.text_input))
            with self.subTest(job=job, valid_manual=True):
                project = deepcopy(saved)
                project["cement_params"]["Main"].update(auto_calc=False, mix_water=30.0, dead_vol=0.0)
                project["cement_params"]["Main"]["yield"] = 1.5
                app = self.app(round_trip(project))
                self.export(app)
                self.assertEqual(app.session_state["cement_params"]["Main"]["yield"], 1.5)
                self.assertEqual(app.session_state["cement_params"]["Main"]["total_sacks"], 50.0 * BBL_TO_CUFT / 1.5)

    def test_batch1_lab_masses_block_confirmation_and_export(self):
        for job in BATCH1_JOBS:
            app = self.configured_app(job)
            self.export(app)
            for mass in ("-10", "abc", "nan", "inf", "", None):
                with self.subTest(job=job, mass=mass):
                    self.phase(app, "phase7")
                    editor = next(e for e in app.dataframe if "_editor_lab_tbl_main_" in e.proto.id)
                    widgets = app._tree.get_widget_states()
                    event = widgets.widgets.add()
                    event.id = editor.proto.id
                    event.string_value = json.dumps({"edited_rows": {"0": {"Mass": mass}},
                                                     "added_rows": [], "deleted_rows": []})
                    app._run(widgets)
                    self.healthy(app)
                    confirm = next(b for b in app.button if b.label == "Confirm measured lab results")
                    self.assertTrue(confirm.disabled)
                    self.assertEqual(compute_phase_status(app.session_state)["phase7"]["level"], "warning")
                    self.assertNotIn("_compiled_doc_bytes", app.session_state)
                    # Even matching restored review metadata cannot bless a bad mass.
                    qc = app.session_state["lab_qc_params"]["Main"]
                    qc["reviewed"] = True
                    qc["review_signature"] = lab_review_signature(qc, app.session_state["lab_grid_dfs"]["Main"])
                    restored = round_trip(app.session_state.to_dict())
                    self.assertEqual(compute_phase_status(restored)["phase7"]["level"], "warning")
                    self.assert_export_blocked(app)
                    self.assertTrue(prepare_calculations(deepcopy(app.session_state.to_dict())))
                    stored = restored["lab_grid_dfs"]["Main"].iloc[0]["Mass"]
                    self.assertTrue(pd.isna(stored) if mass is None else stored == mass)
            # Repaired data can be confirmed and exported without syncing away edits.
            self.phase(app, "phase7")
            editor = next(e for e in app.dataframe if "_editor_lab_tbl_main_" in e.proto.id)
            widgets = app._tree.get_widget_states()
            event = widgets.widgets.add()
            event.id = editor.proto.id
            event.string_value = json.dumps({"edited_rows": {"0": {"Mass": "0"}},
                                             "added_rows": [], "deleted_rows": []})
            app._run(widgets)
            next(b for b in app.button if b.label == "Confirm measured lab results").click().run()
            self.export(app)
            self.assertEqual(app.session_state["lab_grid_dfs"]["Main"].iloc[0]["Mass"], "0")

    def test_batch1_reviewed_thickening_time_is_revalidated(self):
        for job in BATCH1_JOBS:
            valid = self.configured_app(job)
            self.export(valid)
            saved = round_trip(valid.session_state.to_dict())
            compiled = {k: valid.session_state[k] for k in
                        ("_compiled_doc_bytes", "_compiled_doc_filename", "_compiled_doc_signature")}
            for time in ("00:00", "24:01", "99:59", "03.30", None, "00:01", "24:00"):
                with self.subTest(job=job, time=time):
                    project = deepcopy(saved)
                    qc = project["lab_qc_params"]["Main"]
                    qc["thickening_time"] = time
                    qc["review_signature"] = lab_review_signature(qc, project["lab_grid_dfs"]["Main"])
                    app = self.app({**round_trip(project), **compiled})
                    if time in ("00:01", "24:00"):
                        self.export(app)
                        doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                        self.assertTrue(any(time in c.text for t in doc.tables for row in t.rows for c in row.cells))
                    else:
                        self.assertEqual(compute_phase_status(app.session_state)["phase7"]["level"], "warning")
                        self.assertNotIn("_compiled_doc_bytes", app.session_state)
                        self.assert_export_blocked(app)
                        self.assertTrue(prepare_calculations(deepcopy(app.session_state.to_dict())))
                        self.assertEqual(app.session_state["lab_qc_params"]["Main"]["thickening_time"], time)
                        self.phase(app, "phase7")
                        self.assertTrue(next(b for b in app.button if b.label == "Confirm measured lab results").disabled)


    def hardware_event(self, app, edits, navigate=None):
        if navigate:
            app.radio(key="_app_mode_key").set_value(navigate)
        editor = next(e for e in app.dataframe if "_editor_hardware_" in e.proto.id)
        widgets = app._tree.get_widget_states()
        event = widgets.widgets.add()
        event.id = editor.proto.id
        event.string_value = json.dumps({"edited_rows": {}, "added_rows": [], "deleted_rows": [], **edits})
        app._run(widgets)
        self.healthy(app)

    def test_batch2_final_edits_survive_navigation(self):
        import phase_10_procedure
        for index, job in enumerate(BATCH1_JOBS):
            with self.subTest(job=job):
                app = self.configured_app(job)
                self.phase(app, "phase1")
                app.selectbox(key="_w_job_type").set_value('CSG 20"').run()
                name = f"Navigation Well {index}"
                app.text_input(key="_w_well_name").set_value(name)
                app.text_input(key="_w_prepared_by").set_value("Navigation Engineer")
                app.text_input(key="_w_request_number").set_value("REQ-7")
                app.date_input(key="_w_report_date").set_value(date(2026, 9, 20))
                app.selectbox(key="_w_job_type").set_value(job)
                app.radio(key="_app_mode_key").set_value("phase2_3").run()
                self.healthy(app)
                self.assertEqual(app.session_state["well_name"], name)
                self.assertEqual(app.session_state["doc_control"]["well_name"], name)
                self.assertEqual(app.session_state["job_type"], job)
                self.assertEqual(app.session_state["doc_control"]["job_type"], job)
                self.assertEqual(app.session_state["doc_control"]["date"], "2026-09-20")
                next(w for w in app.selectbox if w.label == "Target shoe / treatment depth source").set_value("__manual__")
                app.radio(key="_app_mode_key").set_value("phase4").run()
                self.assertEqual(app.session_state["placement_config"]["target_row"], "__manual__")
                self.phase(app, "phase2_3")
                app.text_input(key="_w_mud_density").set_value("84-86")
                app.text_input(key="_w_plastic_viscosity").set_value("46-48")
                app.text_input(key="_w_yield_point").set_value("16-18")
                app.text_input(key="_w_bhsp").set_value("7300+1000")
                next(w for w in app.number_input if w.label == "Measured target depth (m MD)").set_value(2850.0)
                next(w for w in app.number_input if w.label == "Excess CSG-OH %").set_value(25.0)
                next(w for w in app.number_input if w.label == "Excess CSG-CSG %").set_value(10.5)
                if "TIE BACK" in job:
                    next(w for w in app.selectbox if w.label.startswith("Tie-back host")).select_index(1)
                app.radio(key="_app_mode_key").set_value("phase4").run()
                self.healthy(app)
                well = app.session_state["well_data"]
                self.assertEqual(well["mud_density"], "84-86")
                self.assertEqual(well["effective_mud_density"], 85.0)
                self.assertEqual(well["effective_pv"], 47.0)
                self.assertEqual(well["effective_yp"], 17.0)
                self.assertEqual(well["bhsp"], "7300+1000")
                placement = app.session_state["placement_config"]
                self.assertEqual(placement["manual_depth_m"], 2850.0)
                self.assertEqual(placement["excess_csg_oh_pct"], 25.0)
                self.assertEqual(placement["excess_csg_csg_pct"], 10.5)
                saved = round_trip(app.session_state.to_dict())
                self.assertEqual(saved["well_name"], name)
                self.assertEqual(saved["doc_control"]["job_type"], job)
                self.assertEqual(saved["well_data"]["mud_density"], "84-86")
                app = self.app(saved)
                self.assertEqual(app.text_input(key="_w_well_name").value, name)
                self.assertEqual(app.text_input(key="_w_prepared_by").value, "Navigation Engineer")
                self.assertEqual(app.text_input(key="_w_request_number").value, "REQ-7")
                self.assertEqual(app.selectbox(key="_w_job_type").value, job)
                self.phase(app, "phase2_3")
                self.assertEqual(app.text_input(key="_w_mud_density").value, "84-86")
                self.assertEqual(next(w for w in app.number_input if w.label == "Measured target depth (m MD)").value, 2850.0)
                if job not in ('CMT PLUG', 'CMT SQUEEZE'):
                    table = app.session_state['hardware_table']
                    index = table.index[table['Description'].isin(target_descriptions(job))][0]
                    # Preserve the known explicit Top while editing Tie Back Shoe.
                    md = '0-2850.0' if 'TIE BACK' in job else '2850.0'
                    edits = {str(index): {'MD (m)': md}}
                    if 'TIE BACK' in job:
                        # This synthetic scalar fixture lands at receiver Top;
                        # move that explicit fixture prerequisite with the tie-in.
                        receiver = table.index[table['Description'] == 'Previous Liner'][0]
                        shoe = table.at[receiver, 'MD (m)'].rsplit('-', 1)[1]
                        edits[str(receiver)] = {'MD (m)': '2850.0-' + shoe}
                    self.hardware_event(app, {'edited_rows': edits})
                    token = next(iter(hardware_choices(app.session_state['hardware_table'], target_descriptions(job))))
                    next(w for w in app.selectbox if w.label == 'Target shoe / treatment depth source').set_value(token).run()
                for phase in ("phase4", "phase5", "phase6", "phase7"):
                    self.phase(app, phase)
                next(b for b in app.button if b.label == "Keep reviewed lab entries").click().run()
                next(b for b in app.button if b.label == "Confirm measured lab results").click().run()
                self.export(app)
                with patch.object(phase_10_procedure.st, "session_state", deepcopy(app.session_state.to_dict())):
                    context = phase_10_procedure.build_master_context()
                self.assertEqual(context["well_name"], name)
                self.assertEqual(context["job_type"], job)
                self.assertEqual(context["well_data"]["mud_density"], "84-86")
                self.assertIn("2850.0", context["exec_summary"])
                doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                self.assertIn(name, doc._element.xml)  # Metadata also appears inside nested Word tables.

    def test_batch2_pending_hardware_blocks_stale_export(self):
        actions = ({"edited_rows": {"0": {"MD (m)": "2950"}}},
                   {"added_rows": [{"MD (m)": "1200"}]},
                   {"deleted_rows": [0]})
        for job in BATCH1_JOBS:
            valid = self.configured_app(job)
            self.export(valid)
            saved = round_trip(valid.session_state.to_dict())
            compiled = {key: valid.session_state[key] for key in
                        ("_compiled_doc_bytes", "_compiled_doc_filename", "_compiled_doc_signature")}
            for action in actions:
                edited_md = "3350" if "TIE BACK" in job else "2950"
                if "edited_rows" in action:
                    # The selected Tie Back host must still enclose the target.
                    action = {"edited_rows": {"0": {"MD (m)": edited_md}}}
                if "deleted_rows" in action:
                    action = {"deleted_rows": list(range(len(saved["hardware_table"])))}
                with self.subTest(job=job, action=action):
                    app = self.app({**deepcopy(saved), **compiled})
                    self.phase(app, "phase2_3")
                    original = app.session_state["hardware_table"].copy(deep=True)
                    self.hardware_event(app, action, navigate="phase10")
                    self.assertTrue(app.session_state["hardware_table"].equals(original))
                    self.assertTrue(hardware_draft_pending(app.session_state))
                    self.assertEqual(compute_phase_status(app.session_state)["phase2_3"]["level"], "warning")
                    self.assert_export_blocked(app)
                    self.assertTrue(any("pending hardware" in issue for issue in
                                        prepare_calculations(deepcopy(app.session_state.to_dict()))))
                    restored = round_trip(app.session_state.to_dict())
                    self.assertTrue(hardware_draft_pending(restored))
                    app = self.app(restored)
                    self.assert_export_blocked(app)
                    self.phase(app, "phase2_3")
                    if "added_rows" in action:
                        self.assertTrue(hardware_draft_pending(app.session_state))
                        added_index = str(len(original))
                        self.hardware_event(app, {"edited_rows": {added_index: {
                            "Description": "Open Hole Size", "MD (m)": "3500", "Size (in)": "12.25", "ID (in)": 12.25,
                            "Joint (m)": 3.0, "Weight (ppf)": 30.0, "Grade": "L-80",
                            "Collapse (psi)": 100.0, "Burst (psi)": 200.0}}})
                        open_hole = app.session_state["hardware_table"].iloc[len(original)]
                        for field in ("Joint (m)", "Weight (ppf)", "Collapse (psi)", "Burst (psi)"):
                            self.assertEqual(open_hole[field], 0.0)
                        self.assertEqual(open_hole["Grade"], "-")
                    elif "deleted_rows" in action:
                        self.assertTrue(app.session_state["hardware_table"].empty)
                        self.assertNotEqual(compute_phase_status(app.session_state)["phase2_3"]["level"], "ok")
                        self.hardware_event(app, {"added_rows": original.to_dict("records")})
                    else:
                        self.assertEqual(app.session_state["hardware_table"].iloc[0]["MD (m)"], edited_md)
                    self.assertFalse(hardware_draft_pending(app.session_state))
                    if "TIE BACK" in job:
                        # A changed/deleted host must be selected again after review.
                        next(w for w in app.selectbox if w.label.startswith("Tie-back host")).select_index(1).run()
                    if 'deleted_rows' in action and job not in ('CMT PLUG', 'CMT SQUEEZE'):
                        token = next(iter(hardware_choices(app.session_state['hardware_table'], target_descriptions(job))))
                        next(w for w in app.selectbox if w.label == 'Target shoe / treatment depth source').set_value(token).run()
                    self.assertEqual(compute_phase_status(app.session_state)["phase2_3"]["level"], "ok")
                    # Explicit Round-11 drawing facts; engineering Hardware/target stay unchanged.
                    if job == 'CMT PLUG' and 'edited_rows' in action:
                        next(w for w in app.number_input if w.label == 'Plug bore diameter (in) — 2950–3000 m').set_value(8.5).run()
                    elif job == 'CMT SQUEEZE' and 'edited_rows' in action:
                        next(w for w in app.number_input if w.label == 'Squeeze wall diameter (in) — 3000 m').set_value(8.5).run()
                    elif job == 'CMT SQUEEZE' and 'added_rows' in action:
                        from well_schematic_adapter import additional_drawing_inputs
                        choices = additional_drawing_inputs(app.session_state)['squeeze_targets']
                        token = next(token for token, row in choices.items() if row['target_id'] == 'previous-casing:20')
                        next(w for w in app.selectbox if w.label == 'Squeeze Target for Well Schematic').set_value(token).run()
                    app = self.app(round_trip(app.session_state.to_dict()))
                    self.phase(app, "phase2_3")
                    self.export(app)

    def test_batch2_nested_restoration_and_flat_precedence(self):
        nested = {**well_profile_fixture(3300., bhst=210.), "doc_control": {"job_type": 'CSG 9 5/8"', "well_name": "Nested Well",
                                  "client": "Nested Client", "hole_size": "Approved hole",
                                  "date": "2026-09-20", "prepared_by": "Nested Engineer"},
                  "well_data": {"mud_type": "OBM", "mud_density": "90-92", "plastic_viscosity": "50",
                                "yield_point": "20", "geo_md": 3300.0, "geo_tvd": 3200.0,
                                "bhst": 210, "geo_gradient": 1.40, "bhsp": "6000+500"}}
        for flat in ({}, {"well_name": "Flat Well", "client": "", "job_type": 'CMT PLUG',
                         "mud_density": "84", "geo_md": 3400.0, "report_date": date(2026, 9, 21)}):
            with self.subTest(flat=flat):
                restored = round_trip({**deepcopy(nested), **flat})
                self.assertEqual(restored["well_name"], flat.get("well_name", "Nested Well"))
                self.assertEqual(restored["job_type"], flat.get("job_type", 'CSG 9 5/8"'))
                self.assertEqual(restored["client"], flat.get("client", "Nested Client"))
                self.assertEqual(restored["mud_density"], flat.get("mud_density", "90-92"))
                self.assertEqual(restored["geo_md"], 3300.0)  # Canonical Geometry replaces flat/nested projection precedence.
                self.assertEqual(restored["effective_mud_density"], 84.0 if flat else 91.0)
                app = self.app(restored)
                self.assertEqual(app.text_input(key="_w_well_name").value, restored["well_name"])
                self.phase(app, "phase2_3")
                self.assertEqual(app.text_input(key="_w_mud_density").value, restored["mud_density"])
                self.assertEqual(app.number_input(key="_w_vertical_td").value, restored["geo_md"])
                self.phase(app, "phase4")
                self.phase(app, "phase1")
                saved = round_trip(app.session_state.to_dict())
                for key in ("well_name", "job_type", "client", "mud_density", "geo_md", "report_date"):
                    self.assertEqual(saved[key], restored[key])
                self.assertEqual(saved["doc_control"]["well_name"], saved["well_name"])
                self.assertEqual(saved["doc_control"]["job_type"], saved["job_type"])
                self.assertEqual(saved["well_data"]["mud_density"], saved["mud_density"])
        with self.assertRaises(ValueError):
            round_trip({"doc_control": {"job_type": "Unsupported job"}})
        with self.assertRaises(ValueError):
            round_trip({"well_data": {"geo_md": "invalid"}})

    def test_batch2_well_only_replacement_requires_confirmation(self):
        incoming = BytesIO(json.dumps({"well_name": "Incoming Well", "client": "Incoming Client"}).encode())
        incoming.name = "replacement.json"
        incoming.size = len(incoming.getvalue())
        for field, value in (("mud_type", "OBM"), ("mud_density", "90"), ("plastic_viscosity", "50"),
                             ("yield_point", "20"), ("geo_md", 3300.0), ("geo_tvd", 2800.0),
                             ("bhst", 210), ("geo_gradient", 1.40), ("bhsp", "6000")):
            with self.subTest(field=field):
                app = self.app(well_profile_fixture())
                self.phase(app, "phase2_3")
                if field == "geo_gradient":
                    app.selectbox(key="_w_temperature_source").set_value("Temperature Gradient").run()
                key = {"geo_md": "_w_vertical_td", "geo_tvd": "_w_vertical_td",
                       "bhst": "_w_geothermal_bhst", "geo_gradient": "_w_geothermal_gradient"}.get(field, f"_w_{field}")
                widget = next(w for w in [*app.text_input, *app.number_input, *app.selectbox] if w.key == key)
                widget.set_value(value)
                app.radio(key="_app_mode_key").set_value("phase1").run()
                self.assertTrue(any("unsaved changes" in w.value for w in app.warning))
                uploader_key = f"proj_uploader_{app.session_state.to_dict().get('_uploader_revision', 0)}"
                with patch("streamlit.delta_generator.DeltaGenerator.file_uploader",
                           side_effect=lambda *args, **kwargs: incoming if kwargs.get("key") == uploader_key else None):
                    app.run()
                    self.healthy(app)
                    self.assertTrue(any(b.key == "_confirm_upload_replacement" for b in app.button))
                    self.assertEqual(app.session_state[field], value)
                    next(b for b in app.button if b.key == "_cancel_upload_replacement").click().run()
                    self.healthy(app)
                    self.assertEqual(app.session_state[field], value)
                    self.assertEqual(app.session_state["well_data"][field], value)
                    self.assertFalse(any(b.key == "_confirm_upload_replacement" for b in app.button))
        # Visiting untouched initialization pages must not count as user edits.
        app = self.app()
        for phase in ("phase2_3", "phase4", "phase5", "phase6", "phase7", "phase1"):
            self.phase(app, phase)
        self.assertFalse(any("unsaved changes" in w.value for w in app.warning))
        with patch("streamlit.delta_generator.DeltaGenerator.file_uploader", return_value=incoming):
            app.run()
            self.healthy(app)
            self.assertEqual(app.session_state["well_name"], "Incoming Well")
            self.assertFalse(any(b.key == "_confirm_upload_replacement" for b in app.button))
        # Explicit confirmation uses the same replacement path after a well-only edit.
        app = self.app()
        self.phase(app, "phase2_3")
        app.text_input(key="_w_mud_density").set_value("91").run()
        with patch("streamlit.delta_generator.DeltaGenerator.file_uploader", return_value=incoming):
            app.run()
            next(b for b in app.button if b.key == "_confirm_upload_replacement").click().run()
            self.healthy(app)
            self.assertEqual(app.session_state["well_name"], "Incoming Well")
            self.assertNotIn("mud_density", app.session_state)

    def test_batch2_numeric_hardware_is_normalized_before_mount(self):
        from phase_2_3_well_data import HARDWARE_COLUMNS
        grid = pd.DataFrame([
            ["Previous Casing", 3000.0, 20.0, 18.0, 12.0, 100.0, "K-55", 1000.0, 2000.0],
            [None, None, None, None, None, None, None, None, None],
        ], columns=HARDWARE_COLUMNS)
        for draft in (False, True):
            with self.subTest(draft=draft):
                key = "hardware_editor_draft" if draft else "hardware_table"
                restored = round_trip({"job_type": 'CSG 20"', key: grid.copy(deep=True)})
                self.assertEqual(restored[key].iloc[0]["MD (m)"], "3000.0")
                self.assertEqual(restored[key].iloc[0]["Size (in)"], "20.0")
                self.assertTrue(pd.isna(restored[key].iloc[1]["MD (m)"]))
                self.assertTrue(pd.isna(restored[key].iloc[1]["Size (in)"]))
                app = self.app(restored)
                self.phase(app, "phase2_3")
                source = app.session_state["_editor_source__editor_hardware_0"]
                self.assertEqual(source.iloc[0]["MD (m)"], "3000.0")
                self.assertEqual(source.iloc[0]["Size (in)"], "20.0")
                self.assertTrue(pd.isna(source.iloc[1]["MD (m)"]))
                self.assertTrue(pd.isna(source.iloc[1]["Size (in)"]))
                self.phase(app, "phase1")
                app = self.app(round_trip(app.session_state.to_dict()))
                self.phase(app, "phase2_3")
                # In-memory/legacy state also normalizes before the first mount.
                app = self.app({"job_type": 'CSG 20"', key: grid.copy(deep=True)})
                self.phase(app, "phase2_3")
        from project_io import normalize_hardware_text_columns
        missing = pd.DataFrame({"MD (m)": pd.Series([pd.NA, None], dtype=object),
                                "Size (in)": [None, float("nan")]})
        normalize_hardware_text_columns(missing)
        self.assertTrue(missing.isna().all().all())
        self.assertEqual(missing["MD (m)"].dtype, object)
        self.assertEqual(missing["Size (in)"].dtype, object)

    def test_batch3_first_top_depth_and_restored_repairs(self):
        valid = self.configured_app('CSG 9 5/8"')
        saved = round_trip(valid.session_state.to_dict())
        project = deepcopy(saved)
        project.pop("cement_params")  # First Phase V entry for the slurry.
        app = self.app(project)
        self.phase(app, "phase5")
        # Keep this placement fixture's already-reviewed measured Cement SG.
        next(w for w in app.number_input if w.label == "Cement SG - Main").set_value(3.20).run()
        next(w for w in app.number_input if w.label == "Dead Vol (bbl) - Main").set_value(31.0).run()
        mode = next(w for w in app.selectbox if w.label == "Top of cement - Main")
        self.assertEqual(mode.value, "Not entered")
        self.assertIsNone(app.session_state["cement_params"]["Main"]["top_depth"])
        self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
        mode.set_value("Depth (m MD)").run()
        self.healthy(app)
        depth = next(w for w in app.number_input if w.label == "Top of cement depth (m MD) - Main")
        self.assertIsNone(depth.value)
        self.assertFalse(any(w.label.startswith("Correct Top depth") for w in app.text_input))
        self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
        self.export(app)
        self.phase(app, "phase5")
        next(w for w in app.number_input if w.label == "Top of cement depth (m MD) - Main").set_value(2100.0)
        app.radio(key="_app_mode_key").set_value("phase10").run()
        self.assertEqual(app.session_state["cement_params"]["Main"]["top_depth"], 2100.0)
        self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
        self.export(app)
        saved_depth = round_trip(app.session_state.to_dict())
        for value in (None, "bad depth", -10.0, 2100.0):
            with self.subTest(restored_depth=value):
                project = deepcopy(saved_depth)
                project["cement_params"]["Main"]["top_depth"] = value
                project["cement_params"]["Main"].pop("draft_top_depth", None)
                app = self.app(round_trip(project))
                self.phase(app, "phase5")
                if value is None:
                    self.assertIsNone(next(w for w in app.number_input if w.label.startswith("Top of cement depth")).value)
                    self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
                elif value == 2100.0:
                    self.assertEqual(next(w for w in app.number_input if w.label.startswith("Top of cement depth")).value, value)
                    self.assertEqual(app.session_state["cement_params"]["Main"]["top_depth"], value)
                    self.export(app)
                else:
                    repair = next(w for w in app.text_input if w.label.startswith("Correct Top depth"))
                    self.assertEqual(app.session_state["cement_params"]["Main"]["top_depth"], value)
                    self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
                    repair.set_value("2100").run()
                    next(b for b in app.button if b.label == "Apply corrected values").click().run()
                    self.healthy(app)
                    self.assertEqual(app.session_state["cement_params"]["Main"]["top_depth"], 2100.0)
                    self.export(app)

    def test_batch3_top_ownership_after_job_changes(self):
        import phase_10_procedure as report
        for index, job in enumerate(BATCH1_JOBS):
            with self.subTest(job=job):
                app = self.configured_app(job)
                self.export(app)
                next_job = BATCH1_JOBS[(index + 2) % len(BATCH1_JOBS)]
                for marker in ("absent", None):
                    with self.subTest(legacy_owner=marker):
                        legacy = round_trip(app.session_state.to_dict())
                        legacy["cement_params"]["Main"].pop("top_job_type", None)
                        if marker is None:
                            legacy["cement_params"]["Main"]["top_job_type"] = None
                        old = self.app(legacy)
                        self.assertEqual(compute_phase_status(old.session_state)["phase5"]["level"], "ok")
                        old.selectbox(key="_w_job_type").set_value(next_job)
                        old.radio(key="_app_mode_key").set_value("phase10").run()
                        self.assertEqual(old.session_state["cement_params"]["Main"]["top_job_type"], job)
                        old.session_state["placement_config"]["job_type"] = next_job
                        self.assertEqual(compute_phase_status(old.session_state)["phase5"]["level"], "warning")
                        self.assert_export_blocked(old)
                self.phase(app, "phase1")
                app.selectbox(key="_w_job_type").set_value(next_job)
                app.radio(key="_app_mode_key").set_value("phase10").run()
                self.assertEqual(app.session_state["cement_params"]["Main"]["top_job_type"], job)
                self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "warning")
                self.assert_export_blocked(app)
                # Supply the selected job's explicit current geometry; the old
                # report override still belongs to its original job.
                current = round_trip(app.session_state.to_dict())
                current.update(valid_export_chart_fixture(next_job))
                needs_bhct = job in ('CMT PLUG', 'CMT SQUEEZE') and next_job not in ('CMT PLUG', 'CMT SQUEEZE')
                if needs_bhct:
                    current['lab_qc_params']['Main']['rheology']['bhct_down'] = valid_export_rheology_fixture()['bhct_down']
                app = self.app(current)
                if needs_bhct:
                    self.phase(app, 'phase7')
                    next(b for b in app.button if b.label == 'Confirm measured lab results').click().run()
                self.phase(app, "phase2_3")
                token = current['placement_config']['target_row']
                next(w for w in app.selectbox if w.label == "Target shoe / treatment depth source").set_value(token).run()
                if next_job in ('CMT PLUG', 'CMT SQUEEZE'):
                    next(w for w in app.number_input if w.label == "Measured target depth (m MD)").set_value(3000.0).run()
                if "TIE BACK" in next_job:
                    next(w for w in app.selectbox if w.label.startswith("Tie-back host")).select_index(1).run()
                self.assertEqual(compute_phase_status(app.session_state)["phase2_3"]["level"], "ok")
                volume_driven = next_job not in ("CMT PLUG", "CMT SQUEEZE")
                self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok" if volume_driven else "warning")
                restored = round_trip(app.session_state.to_dict())
                app = self.app(restored)
                ensure_current_centralizer(restored)
                with patch.object(report.st, "session_state", deepcopy(restored)):
                    if volume_driven:
                        from cement_chart_model import resolve_cement_placement
                        placement = resolve_cement_placement(restored)
                        context = report.build_master_context()
                        self.assertEqual(context["slurries"][0]["top"], f"{placement[0]['top_md']:.1f} m")
                    else:
                        with self.assertRaises(ValueError):
                            report.build_master_context()
                if volume_driven:
                    self.export(app)
                else:
                    self.assert_export_blocked(app)
                self.phase(app, "phase5")
                mode = next(w for w in app.selectbox if w.label == "Top of cement - Main")
                self.assertEqual(mode.value, "Not entered")
                mode.set_value("Depth (m MD)").run()
                next(w for w in app.number_input if w.label.startswith("Top of cement depth")).set_value(2100.0).run()
                self.assertEqual(app.session_state["cement_params"]["Main"]["top_job_type"], next_job)
                self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
                self.export(app)

    def test_batch3_top_limits_match_export_readiness(self):
        import phase_10_procedure as report
        for job in BATCH1_JOBS:
            saved = round_trip(self.configured_app(job).session_state.to_dict())
            for depth, accepted in ((2999.0, True), (3000.0, False), (3001.0, False), (0.0, False),
                                    (-10.0, False), ("2000-2100", False), ("NaN", False)):
                with self.subTest(job=job, top=depth):
                    project = deepcopy(saved)
                    project["cement_params"]["Main"].update(top_mode="Depth (m MD)", top_depth=depth, top_job_type=job)
                    app = self.app(round_trip(project))
                    volume_driven = job not in ('CMT PLUG', 'CMT SQUEEZE')
                    self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok" if accepted or volume_driven else "warning")
                    if volume_driven:
                        self.export(app)
                        from cement_chart_model import resolve_cement_placement
                        baseline_placement = resolve_cement_placement(saved)
                        self.assertEqual(resolve_cement_placement(app.session_state), baseline_placement)
                        with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                            context = report.build_master_context()
                        expected_top = (f"{depth:.1f} m" if isinstance(depth, (float, int)) and depth > 0 else
                                        f"{baseline_placement[0]['top_md']:.1f} m")
                        self.assertEqual(context["slurries"][0]["top"], expected_top)
                        self.assertEqual(context["slurries"][0]["bottom"], "3000.0 m MD")
                    elif accepted:
                        self.export(app)
                        with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                            context = report.build_master_context()
                        self.assertEqual(context["slurries"][0]["top"], "2999.0 m")
                        self.assertEqual(context["slurries"][0]["bottom"], "3000.0 m MD")
                    else:
                        self.assert_export_blocked(app)
                        with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                            with self.assertRaises(ValueError):
                                report.build_master_context()
            # Legacy approved depths without top_mode/ownership remain supported.
            project = deepcopy(saved)
            top = project["cement_params"]["Main"]
            top.pop("top_mode", None)
            top.pop("top_job_type", None)
            top["top_depth"] = 2100.0
            app = self.app(round_trip(project))
            self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
            self.export(app)
            project["placement_config"]["target_row"] = "__manual__"
            project["placement_config"]["manual_depth_m"] = 0.0
            self.assertEqual(compute_phase_status(project)["phase5"]["level"], "warning")

    def test_batch3_chained_word_placement_matches_summary(self):
        import phase_10_procedure as report
        for job in ('CSG 9 5/8"', 'LNR 7"', 'TIE BACK LNR 7"'):
            valid = self.configured_app(job)
            self.export(valid)  # Single-slurry behavior remains valid.
            saved = round_trip(valid.session_state.to_dict())
            for slurries, depths in ((["Lead", "Main"], {"Main": 1000.0, "Lead": 2000.0}),
                                     (["Lead #1", "Lead #2", "Main"], {"Main": 500.0, "Lead #1": 1000.0, "Lead #2": 2000.0})):
                with self.subTest(job=job, slurries=slurries):
                    project = deepcopy(saved)
                    project["fluids_config"]["active"] = [*slurries, "Displacement Fluid"]
                    for slurry in slurries:
                        project["fluids_config"]["params"][slurry] = deepcopy(project["fluids_config"]["params"]["Main"])
                        project["cement_params"][slurry] = deepcopy(saved["cement_params"]["Main"])
                        project["cement_params"][slurry].update(top_mode="Not entered", top_depth=None, top_job_type=job)
                        project["cement_additives_dfs"][slurry] = project["cement_additives_dfs"]["Main"].copy(deep=True)
                        project.setdefault("lab_qc_params", {}).setdefault(slurry, {}).update(
                            thickening_time="03:30", free_water_45=0.0, surface_hardened_hours=8.0,
                            rheology=valid_export_rheology_fixture(), **thickening_fixture(), **compressive_fixture())
                    app = self.app(round_trip(project))
                    for phase in ("phase2_3", "phase4", "phase5", "phase7"):
                        self.phase(app, phase)
                    for _ in slurries:
                        confirms = [b for b in app.button if b.label == "Confirm measured lab results"]
                        if confirms:
                            confirms[0].click().run()
                    self.assertEqual(compute_phase_status(app.session_state)["phase5"]["level"], "ok")
                    app = self.app(round_trip(app.session_state.to_dict()))
                    for phase in ("phase2_3", "phase4", "phase5", "phase7"):
                        self.phase(app, phase)
                    self.export(app)
                    with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                        context = report.build_master_context()
                    from cement_chart_model import resolve_cement_placement
                    hydraulic_slurries = [name for name in materials_db.PLACEMENT_SLURRIES if name in slurries]
                    expected = [(row['fluid'], round(row['bottom_md'], 1), round(row['top_md'], 1))
                                for row in resolve_cement_placement(app.session_state)]
                    payload = [(p["name"], float(p["bottom"].split()[0]), float(p["top"].split()[0]))
                               for p in context["slurries"]]
                    # Chained upper bottoms use a top label, without the MD suffix.
                    summary = [(name.title(), float(bottom), float(top)) for name, bottom, top in re.findall(
                        r"(main|lead(?: #\d)?) cement slurry will be cemented from (?:the shoe at )?([\d.]+) m(?: MD)? to ([\d.]+) m", context["exec_summary"])]
                    # Report sections follow presentation order; the summary
                    # keeps its established deepest-first engineering chain.
                    expected_report = [next(row for row in expected if row[0] == name) for name in slurries]
                    self.assertEqual(payload, expected_report)
                    self.assertEqual(summary, expected)
                    opening = ("Tie Back cementing will be set at 3000.0 m MD" if "TIE BACK" in job
                               else "will be set and cemented at 3000.0 m MD")
                    self.assertIn(opening, context["exec_summary"])
                    doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                    word = []
                    for table in doc.tables:
                        title = table.rows[0].cells[0].text
                        if title.endswith(" Cement Slurry Data"):
                            row = next(r for r in table.rows if r.cells[0].text == "Bottom")
                            word.append((title.removesuffix(" Cement Slurry Data"),
                                         float(row.cells[1].text.split()[0]), float(row.cells[3].text.split()[0])))
                    self.assertEqual(word, expected_report)
                    # Word-only overrides cannot change the calculated chain or export readiness.
                    invalid = round_trip(app.session_state.to_dict())
                    invalid["cement_params"][hydraulic_slurries[0]]["top_depth"] = 2500.0
                    bad = self.app(invalid)
                    self.assertEqual(compute_phase_status(bad.session_state)["phase5"]["level"], "ok")
                    self.assertEqual(resolve_cement_placement(bad.session_state), resolve_cement_placement(app.session_state))
                    self.export(bad)
        # Sibling jobs retain independent target-based bottoms, without chaining.
        from placement import slurry_intervals
        for job in ('CMT PLUG', 'CMT SQUEEZE'):
            intervals = slurry_intervals(None, job, {"job_type": job, "target_row": "__manual__", "manual_depth_m": 3000.0},
                                         ["Lead", "Main"], {"Lead": {"top_mode": "Depth (m MD)", "top_depth": 1000.0},
                                                            "Main": {"top_mode": "Depth (m MD)", "top_depth": 2000.0}})
            self.assertEqual(list(intervals), ["Lead", "Main"])
            self.assertTrue(all(p["bottom_depth"] == 3000.0 for p in intervals.values()))

    def test_batch3_note_and_procedure_use_total_water(self):
        import phase_10_procedure as report
        from phase_5_cement import build_components, calculate_base_results
        for job in BATCH1_JOBS:
            valid = self.configured_app(job, additives=True)
            saved = round_trip(valid.session_state.to_dict())
            for auto, dead in ((True, 20.0), (False, 20.0), (False, 0.0)):
                with self.subTest(job=job, automatic=auto, dead_volume=dead):
                    project = deepcopy(saved)
                    p = project["cement_params"]["Main"]
                    p.update(auto_calc=auto, dead_vol=dead)
                    if not auto:
                        p.update(mix_water=30.0, manual_mix_water=30.0, manual_yield=1.5)
                        p["yield"] = 1.5
                        project["cement_additives_dfs"]["Main"].loc[0, "User Input"] = 60.0 / (50.0 * BBL_TO_CUFT / 1.5)
                    app = self.app(round_trip(project))
                    self.phase(app, "phase5")
                    self.phase(app, "phase7")
                    keeps = [b for b in app.button if b.label == "Keep reviewed lab entries"]
                    if keeps:
                        keeps[0].click().run()
                        next(b for b in app.button if b.label == "Confirm measured lab results").click().run()
                    p = deepcopy(app.session_state["cement_params"]["Main"])
                    adds = app.session_state["cement_calc_Main"].copy(deep=True)
                    formulation = app.session_state["cement_additives_dfs"]["Main"]
                    fluid = app.session_state["fluid_data"]["Main"]
                    engine = calculate_base_results(deepcopy(p), fluid["volume"], float(fluid["effective_density"]), *build_components(formulation))
                    if auto:
                        self.assertEqual(p["mix_water"], engine["field_water_bbl"])
                    else:
                        self.assertEqual(p["mix_water"], 30.0)
                        self.assertEqual(p["yield"], 1.5)
                        self.assertEqual(p["total_sacks"], 50.0 * BBL_TO_CUFT / 1.5)
                    self.assertEqual(p["dead_vol"], dead)
                    total = round_half_up(p["mix_water"] + dead, 1)
                    concentration = formulation.iloc[0]["User Input"] * p["total_sacks"] / p["mix_water"]
                    self.assertEqual(float(adds.iloc[0]["(lbs or gal)/bbl"].split()[0]), round_half_up(concentration, 3))
                    amount = float(adds.iloc[0]["lbs or gal (with dead Vol.)"].split()[0])
                    self.assertEqual(amount, round_half_up((p["mix_water"] + dead) * concentration, 2))
                    if not auto:
                        self.assertEqual(float(adds.iloc[0]["(lbs or gal)/bbl"].split()[0]), 2.0)
                        self.assertEqual(amount, 100.0 if dead else 60.0)
                    self.assertIn(f"**{total:.1f} bbl**", app.session_state["cement_note_Main"])
                    self.export(app)
                    with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                        context = report.build_master_context()
                    payload = context["slurries"][0]
                    self.assertEqual(payload["mix_water_bbl"], p["mix_water"])
                    self.assertEqual(payload["dead_vol_bbl"], dead)
                    self.assertEqual(payload["total_water_bbl"], p["mix_water"] + dead)
                    self.assertIn(f"{total:.1f} bbl Fresh Water", payload["note_mix"])
                    water_line = next(line for line in context["procedure_text"].splitlines() if "Fill up" in line)
                    self.assertIn(f"{total:.1f} bbl", water_line)
                    self.assertEqual(app.session_state["cement_params"]["Main"], p)
                    pd.testing.assert_frame_equal(app.session_state["cement_calc_Main"], adds)

    def test_batch4_word_units_and_surface(self):
        import phase_10_procedure as report
        for job in BATCH1_JOBS:
            with self.subTest(job=job):
                app = self.configured_app(job, optional_fluids=True, include_standalone_spacer=False)
                self.phase(app, "phase5")
                next(w for w in app.selectbox if w.label == "Top of cement - Main").set_value("Depth (m MD)").run()
                next(w for w in app.number_input if w.label == "Top of cement depth (m MD) - Main").set_value(1000.0).run()
                self.export(app, build_timeout=120)
                doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                slurry = next(t for t in doc.tables if t.rows[0].cells[0].text == "Main Cement Slurry Data")
                placement = next(r for r in slurry.rows if r.cells[0].text == "Bottom")
                self.assertEqual(placement.cells[1].text, "3000.0 m MD")
                self.assertEqual(placement.cells[3].text, "1000.0 m")
                self.assertEqual(slurry.rows[1].cells[1].text, "50.0 bbl")
                self.assertEqual(slurry.rows[1].cells[3].text, "118.0 pcf")
                self.assertTrue(slurry.rows[4].cells[1].text.endswith(" cuft/sk"))
                self.assertFalse(any(t.cell(0, 0).text in ("Spacer Formulation Data", "Spacer Additives Data") for t in doc.tables))
                sequence = next(t for t in doc.tables if any("Spacer Behind" == c.text for r in t.rows for c in r.cells))
                behind = next(r for r in sequence.rows if r.cells[0].text == "Spacer Behind")
                self.assertIn("50.0", [c.text for c in behind.cells])
                self.assertIn("80.0", [c.text for c in behind.cells])
                preflush = next(t for t in doc.tables if t.rows[0].cells[0].text == "Pre Flush Data")
                self.assertEqual(preflush.rows[1].cells[2].text, "50.0 bbl")
                self.assertEqual(preflush.rows[1].cells[4].text.count("pcf"), 1)
                word_text = "\n".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
                self.assertNotRegex(word_text, r"\bm MD m\b|\bm m\b|\bpcf pcf\b")
                with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                    context = report.build_master_context()
                self.assertIn("3000.0 m MD", context["exec_summary"])
                self.assertEqual(context["slurries"][0]["top"], "1000.0 m")
                # Surface is a representation, not a numeric depth with a unit.
                project = round_trip(app.session_state.to_dict())
                project["cement_params"]["Main"].update(top_mode="Surface", top_depth=0.0)
                app = self.app(round_trip(project))
                for phase in ("phase2_3", "phase4", "phase5", "phase6", "phase7"):
                    self.phase(app, phase)
                self.export(app)
                doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                slurry = next(t for t in doc.tables if t.rows[0].cells[0].text == "Main Cement Slurry Data")
                placement = next(r for r in slurry.rows if r.cells[0].text == "Bottom")
                self.assertEqual(placement.cells[1].text, "3000.0 m MD")
                self.assertEqual(placement.cells[3].text, "surface")

    def test_batch4_single_slurry_water_label(self):
        import phase_10_procedure as report
        for job in BATCH1_JOBS:
            saved = round_trip(self.configured_app(job).session_state.to_dict())
            for slurry in ("Main", "Lead", "Tail"):
                with self.subTest(job=job, slurry=slurry):
                    project = deepcopy(saved)
                    project["fluids_config"]["active"] = [slurry, "Displacement Fluid"]
                    project["fluids_config"]["params"][slurry] = deepcopy(saved["fluids_config"]["params"]["Main"])
                    for key in ("cement_params", "cement_additives_dfs", "lab_qc_params"):
                        project[key][slurry] = deepcopy(saved[key]["Main"])
                    if slurry == "Tail":
                        project["cement_params"][slurry].update(top_mode="Depth (m MD)", top_depth=2800.0)
                    app = self.app(round_trip(project))
                    for phase in ("phase2_3", "phase4", "phase5", "phase7"):
                        self.phase(app, phase)
                    confirms = [b for b in app.button if b.label == "Confirm measured lab results"]
                    if confirms:
                        confirms[0].click().run()
                        self.healthy(app)
                    self.export(app)
                    with patch.object(report.st, "session_state", deepcopy(app.session_state.to_dict())):
                        context = report.build_master_context()
                    self.assertEqual([p["name"] for p in context["slurries"]], [slurry])
                    water_line = next(line for line in context["procedure_text"].splitlines() if "Fill up" in line)
                    prefix = "PLUG" not in job and not ("LNR" in job and "TIE BACK" not in job)
                    total = context["slurries"][0]["total_water_bbl"]
                    expected = (f"with {total:.1f} bbl fresh water" if "PLUG" in job else
                                f"Fresh water ({slurry + ': ' if prefix else ''}{total:.1f} bbl)")
                    self.assertIn(expected, water_line)
                    if slurry != "Main":
                        self.assertNotIn("Main:", water_line)
                    doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                    word_line = next(p.text for p in doc.paragraphs if "Fill up" in p.text)
                    self.assertIn(expected, word_line)

    def test_batch4_spacer_zero_positive_and_missing_dosage(self):
        for job in BATCH1_JOBS:
            saved = round_trip(self.configured_app(job, optional_fluids=True, include_standalone_spacer=False).session_state.to_dict())
            for dosage in (0.0, 1.25, None):
                with self.subTest(job=job, dosage=dosage):
                    project = deepcopy(saved)
                    project["spacer_dfs"]["Spacer Behind"].loc[0, "User Input (% or gal)"] = dosage
                    app = self.app(round_trip(project))
                    for phase in ("phase2_3", "phase4", "phase5", "phase6", "phase7"):
                        self.phase(app, phase)
                    amount = app.session_state["spacer_dfs"]["Spacer Behind"].iloc[0]["User Input (% or gal)"]
                    if dosage is None:
                        self.assertTrue(pd.isna(amount))
                    else:
                        self.assertEqual(amount, dosage)
                    self.assertEqual(compute_phase_status(app.session_state)["phase6"]["level"], "ok")
                    before = app.session_state["spacer_dfs"]["Spacer Behind"].copy(deep=True)
                    self.export(app, build_timeout=120)
                    doc = Document(BytesIO(app.session_state["_compiled_doc_bytes"]))
                    self.assertFalse(any(t.cell(0, 0).text in ("Spacer Formulation Data", "Spacer Additives Data") for t in doc.tables))
                    import phase_10_procedure as report
                    with patch.object(report.st, "session_state", app.session_state.to_dict()):
                        ctx = report.build_master_context()
                    self.assertEqual(ctx["spacers"], [])
                    behind = next(row for row in ctx["fluids_train"] if row["name"] == "Spacer Behind")
                    self.assertEqual(behind["volume"], project["fluids_config"]["params"]["Spacer Behind"]["volume"])
                    self.assertIn("Spacer Behind", " ".join(c.text for t in doc.tables for r in t.rows for c in r.cells))
                    pd.testing.assert_frame_equal(app.session_state["spacer_dfs"]["Spacer Behind"], before)

if __name__ == "__main__":
    unittest.main()
