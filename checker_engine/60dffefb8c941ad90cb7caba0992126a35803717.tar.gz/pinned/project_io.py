"""Parse a project completely before replacing the current session."""
import hashlib
import json
import math
from datetime import date, datetime
import pandas as pd
import materials_db
from well_profile import validate_well_inputs
from rheology import validate_rheology_inputs
from engineering_tools import (THICKENING_TEST_FIELDS, compressive_inputs,
                               safe_float, require_fluid_density)
from project_state import (SLURRIES, is_project_key, restore_canonical_fields,
                           migrate_material_properties, validate_material_properties,
                           DOC_CONTROL_DEFAULTS, WELL_DATA_DEFAULTS)
from placement import EXCESS_FIELDS, excess_percentage, validate_executive_summary_config
from cement_chart_model import validate_chart_inputs


def content_signature(raw_bytes):
    return hashlib.sha256(raw_bytes).hexdigest()


def _reject_constant(token):
    raise ValueError(f"Non-JSON numeric value: {token}")


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate project field: {key}")
        result[key] = value
    return result


def _check_finite(value, path="project"):
    """Reject overflowed JSON exponents and invalid numbers in table cells."""
    if isinstance(value, (int, float)) and not isinstance(value, bool) and safe_float(value, None) is None:
        raise ValueError(f"{path} must contain a finite number")
    if isinstance(value, pd.DataFrame):
        if not value.columns.is_unique:
            raise ValueError(f"{path}: duplicate DataFrame column labels are not supported.")
        for index, row in enumerate(value.to_dict("records")):
            for column, cell in row.items():
                # JSON null becomes NaN in a numeric DataFrame column.
                # Allow unfinished table drafts to reopen; the Word export
                # path validates required additive concentrations separately.
                if isinstance(cell, float) and math.isnan(cell):
                    continue
                _check_finite(cell, f"{path}[{index}].{column}")
    elif isinstance(value, dict):
        for key, item in value.items():
            _check_finite(item, f"{path}.{key}")
    elif isinstance(value, list):
        for idx, item in enumerate(value):
            _check_finite(item, f"{path}[{idx}]")


def _check_numeric_fields(container, fields, path, nullable=(), nonnegative=()):
    """Reject malformed saved numbers before any session state is replaced."""
    for field in fields:
        if field not in container:
            continue
        value = container[field]
        if value is None and field in nullable:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or safe_float(value, None) is None:
            raise ValueError(f"{path}.{field} must be a finite number (got {value!r}).")
        if field in nonnegative and value < 0:
            raise ValueError(f"{path}.{field} must be nonnegative.")


def _check_thickening_draft(container, path):
    # Completion belongs to Phase VII/export; malformed HH:MM text may reopen.
    _check_numeric_fields(container, ("thickening_cell",), path, nullable=("thickening_cell",))
    for field, _, kind in THICKENING_TEST_FIELDS:
        if field == "thickening_time" or kind == "number" or field not in container:
            continue
        if container[field] is not None and not isinstance(container[field], str):
            raise ValueError(f"{path}.{field} must be text or an unfinished blank.")


def _check_table_numeric_cells(table, fields, path):
    """Keep JSON booleans/containers out of numeric editors and coercion paths.

    Numeric text and null cells remain repairable drafts; bool is a different
    JSON type and must never silently become a one/zero engineering value.
    """
    for index, row in enumerate(table.to_dict("records")):
        for field in fields:
            if isinstance(row.get(field), (bool, list, dict)):
                raise ValueError(f"{path}[{index}].{field} must not be boolean or a container.")


def _validate_project(data):
    if not any(key in data for key in ("job_type", "well_name", "doc_control",
                                       "well_data", "hardware_table", "fluids_config")):
        raise ValueError("No recognizable well or project fields were found.")
    for key in ("job_type", "well_name"):
        if key in data and not isinstance(data[key], str):
            raise ValueError(f"{key} must be text.")
    if "job_type" in data and data["job_type"] not in materials_db.JOB_TYPES:
        raise ValueError("job_type is not supported by this application.")
    for field in ("request_description_customized", "revision_description_customized"):
        if field in data and not isinstance(data[field], bool):
            raise ValueError(f"{field} must be a boolean.")
    schemas = {
        "doc_control": dict, "well_data": dict, "fluids_config": dict,
        "fluid_data": dict, "cement_params": dict, "cement_additives_dfs": dict,
        "lab_grid_dfs": dict, "lab_qc_params": dict, "lab_source_signatures": dict,
        "report_text_state": dict, "placement_config": dict, "spacer_dfs": dict,
        "preflush_config": dict, "hardware_table": pd.DataFrame,
        "hardware_editor_draft": pd.DataFrame,
        "inactive_slurry_drafts": dict,
        "cement_initialized_slurries": list, "lab_initialized_slurries": list,
        "spacer_initialized_names": list, "active_fluids": dict,
    }
    for key, expected in schemas.items():
        if key in data and not isinstance(data[key], expected):
            raise ValueError(f"{key} must be a {expected.__name__}, not {type(data[key]).__name__}.")
    from phase_1_doc_control import DOCUMENT_DATE_FIELDS
    for name, defaults in (("doc_control", DOC_CONTROL_DEFAULTS), ("well_data", WELL_DATA_DEFAULTS)):
        for container, path in ((data, "project"), (data.get(name, {}), name)):
            for field, default in defaults.items():
                types = (str, date) if name == "doc_control" and field in DOCUMENT_DATE_FIELDS else (str,)
                if (isinstance(default, str) and field in container
                        and container[field] is not None and not isinstance(container[field], types)):
                    raise ValueError(f"{path}.{field} has an invalid text/calendar value.")
    doc_date = data.get("doc_control", {}).get("date")
    if doc_date is not None and not isinstance(doc_date, (str, date)):
        raise ValueError("doc_control.date must be a date, ISO date text or an unfinished blank.")
    if "report_date" in data:
        value = data["report_date"]
        if isinstance(value, str):
            try:
                date.fromisoformat(value)
            except ValueError:
                raise ValueError("report_date must be a valid ISO date.") from None
        elif value is not None and not isinstance(value, (date, datetime)):
            raise ValueError("report_date must be a date or an unfinished blank.")
    if "standalone_spacer_config" in data:
        from standalone_spacer import validate_config
        validate_config(data["standalone_spacer_config"], data.get("job_type", 'CSG 20"'))
    for field, _, _ in EXCESS_FIELDS:
        excess_percentage(data.get("placement_config", {}), field)
    placement = data.get("placement_config", {})
    _check_numeric_fields(placement, ("tie_back_liner_lap_m", "squeeze_depth_m"),
                          "placement_config", nullable=("tie_back_liner_lap_m", "squeeze_depth_m"),
                          nonnegative=("tie_back_liner_lap_m", "squeeze_depth_m"))
    if "target_string_id" in placement and not isinstance(placement["target_string_id"], str):
        raise ValueError("placement_config.target_string_id must be a string token.")
    for field in ("target_row", "host_row"):
        if placement.get(field) is not None and not isinstance(placement[field], str):
            raise ValueError(f"placement_config.{field} must be a string token or null.")
    if "executive_summary_config" in data:
        validate_executive_summary_config(data["executive_summary_config"])
    if "centralizer_config" in data:
        from phase_9_centralizer import validate_config
        validate_config(data["centralizer_config"])
    if "schematic_config" in data:
        from well_schematic_adapter import validate_schematic_config
        validate_schematic_config(data["schematic_config"])
    if "formation_pressure_config" in data:
        from cement_chart_model import validate_formation_pressure_config
        validate_formation_pressure_config(data["formation_pressure_config"])
    cfg = data.get("fluids_config", {})
    if cfg and (not isinstance(cfg.get("active", []), list)
                or not all(isinstance(x, str) for x in cfg.get("active", []))
                or any(x not in materials_db.FLUID_TYPES for x in cfg.get("active", []))
                or not isinstance(cfg.get("params", {}), dict)
                or any(not isinstance(v, dict) for v in cfg.get("params", {}).values())):
        raise ValueError("fluids_config needs a fluid list and parameter records.")
    if data.get("job_type") == materials_db.CT_JOB:
        forbidden = [name for name in cfg.get("active", [])
                     if name in materials_db.CEMENT_FORMULATION_FLUIDS and name != "Main"]
        if forbidden:
            raise ValueError("CMT PLUG WITH CT permits only Main cement slurry; invalid active selection: " + ", ".join(forbidden))
        hardware = data.get("hardware_table")
        if isinstance(hardware, pd.DataFrame) and "Description" in hardware:
            rows = hardware[hardware["Description"].eq("CT")]
            # Missing inputs remain savable drafts; supplied invalid/ambiguous data is not admitted.
            if len(rows) > 1 or (len(rows) == 1 and not _is_missing_cell(rows.iloc[0].get("MD (m)"))
                                and rows.iloc[0].get("MD (m)") != ""):
                from placement import ct_setting_depth
                ct_setting_depth(hardware)
    for key in ("cement_params", "lab_qc_params", "report_text_state", "fluid_data"):
        if any(not isinstance(item, dict) for item in data.get(key, {}).values()):
            raise ValueError(f"{key} contains an invalid record.")
    for name, record in data.get("fluid_data", {}).items():
        for field in ("volume", "density", "effective_density", "pump_rate", "min_rate", "duration_min", "cumul_time_min"):
            if field not in record:
                continue
            value = record[field]
            if isinstance(value, (bool, list, dict)):
                raise ValueError(f"fluid_data.{name}.{field} must not be boolean or a container.")
            if value is None or value == "":
                continue  # Missing inputs remain reopenable unfinished drafts.
            if field == "density":
                try:
                    require_fluid_density(name, value)
                except (TypeError, ValueError, OverflowError) as exc:
                    raise ValueError(f"fluid_data.{name}.density: {exc}") from None
            elif field != "pump_rate" and safe_float(value, None) is None:
                raise ValueError(f"fluid_data.{name}.{field} must be a finite number.")
    if "ct_stage_config" in data:
        from ct_stages import validate_stage_config
        validate_stage_config(data)
    for key in ("cement_additives_dfs", "lab_grid_dfs", "spacer_dfs"):
        if any(not isinstance(item, pd.DataFrame) for item in data.get(key, {}).values()):
            raise ValueError(f"{key} contains a table that could not be restored.")
    for key, fields in (("cement_additives_dfs", ("User Input", "Density")),
                        ("spacer_dfs", ("User Input (% or gal)",))):
        for name, table in data.get(key, {}).items():
            _check_table_numeric_cells(table, fields, f"{key}.{name}")
    for name, record in data.get("report_text_state", {}).items():
        history = record.get("history", [])
        if not isinstance(history, list) or any(not isinstance(text, str) for text in history):
            raise ValueError(f"report_text_state.{name}.history must be a list of text revisions.")
    archived_fields = {"cement_additives_dfs": pd.DataFrame, "cement_params": dict,
                       "lab_grid_dfs": pd.DataFrame, "lab_qc_params": dict}
    for slurry, draft in data.get("inactive_slurry_drafts", {}).items():
        if slurry not in SLURRIES or not isinstance(draft, dict) or any(
                field not in archived_fields or not isinstance(value, archived_fields[field])
                for field, value in draft.items()):
            raise ValueError(f"inactive_slurry_drafts.{slurry} has an invalid formulation.")
        for field, required in (("cement_additives_dfs", {"Material Type", "Name", "Physical State", "Mix Method", "User Input"}),
                                ("lab_grid_dfs", {"Material", "Concentration", "Unit", "Mass", "Lot No"})):
            if field in draft and not required.issubset(draft[field].columns):
                raise ValueError(f"inactive_slurry_drafts.{slurry}.{field} is missing required columns.")
        if "cement_additives_dfs" in draft:
            _check_table_numeric_cells(draft["cement_additives_dfs"], ("User Input", "Density"),
                                       f"inactive_slurry_drafts.{slurry}.cement_additives_dfs")
        if "cement_params" in draft:
            _check_numeric_fields(draft["cement_params"], ("yield", "mix_water", "dead_vol", "total_sacks", "cmt_sg", "report_bottom_depth"),
                                  f"inactive_slurry_drafts.{slurry}.cement_params",
                                  nullable=("dead_vol", "report_bottom_depth"), nonnegative=("report_bottom_depth",))
        if "lab_qc_params" in draft:
            if "reviewed" in draft["lab_qc_params"] and not isinstance(draft["lab_qc_params"]["reviewed"], bool):
                raise ValueError(f"inactive_slurry_drafts.{slurry}.lab_qc_params.reviewed must be boolean.")
            if "bhct" in draft["lab_qc_params"]:
                raise ValueError(f"inactive_slurry_drafts.{slurry}.lab_qc_params.bhct is not allowed; BHCT belongs to Well Data.")
            if "compressive" in draft["lab_qc_params"] or "comp_test" in draft["lab_qc_params"]:
                compressive_inputs(draft["lab_qc_params"])
            _check_thickening_draft(draft["lab_qc_params"], f"inactive_slurry_drafts.{slurry}.lab_qc_params")
            if "rheology" in draft["lab_qc_params"]:
                validate_rheology_inputs(draft["lab_qc_params"]["rheology"])
            _check_numeric_fields(draft["lab_qc_params"], ("api_fl", "free_water", "free_water_45", "surface_hardened_hours"),
                                  f"inactive_slurry_drafts.{slurry}.lab_qc_params",
                                  nullable=("free_water_45", "surface_hardened_hours"))
    validate_well_inputs(data.get("well_geometry", {}), data.get("geothermal_config", {}))
    # Empty well number inputs are valid unfinished drafts, not malformed numbers.
    for container, path in ((data, "project"), (data.get("well_data", {}), "well_data")):
        validate_chart_inputs(container, data.get("placement_config", {}))
        _check_numeric_fields(container, tuple(field for field in ("geo_md", "geo_tvd", "geo_gradient", "bhst", "bhct")
                                               if container.get(field) is not None), path)
    auto_fields = data.get("well_auto_fields", {})
    if (not isinstance(auto_fields, dict) or any(field not in ("bhsp",)
            or not isinstance(enabled, bool) for field, enabled in auto_fields.items())):
        raise ValueError("well_auto_fields must contain boolean BHSP provenance.")
    for name, params in cfg.get("params", {}).items():
        _check_numeric_fields(params, ("volume",), f"fluids_config.params.{name}")
    for name, params in data.get("cement_params", {}).items():
        _check_numeric_fields(params, ("yield", "mix_water", "dead_vol", "total_sacks", "cmt_sg", "report_bottom_depth"),
                              f"cement_params.{name}", nullable=("dead_vol", "report_bottom_depth"),
                              nonnegative=("report_bottom_depth",))
    for name, params in data.get("lab_qc_params", {}).items():
        if "reviewed" in params and not isinstance(params["reviewed"], bool):
            raise ValueError(f"lab_qc_params.{name}.reviewed must be boolean.")
        if name == "Spacer":
            if "review_signature" in params and not isinstance(params["review_signature"], str):
                raise ValueError("lab_qc_params.Spacer.review_signature must be text.")
        if "bhct" in params:
            raise ValueError(f"lab_qc_params.{name}.bhct is not allowed; BHCT belongs to Well Data.")
        if "compressive" in params or "comp_test" in params:
            compressive_inputs(params)
        _check_thickening_draft(params, f"lab_qc_params.{name}")
        if "rheology" in params:
            validate_rheology_inputs(params["rheology"])
        _check_numeric_fields(params, ("api_fl", "free_water", "free_water_45", "surface_hardened_hours"), f"lab_qc_params.{name}",
                              nullable=("free_water_45", "surface_hardened_hours"))
    hardware_columns = {"Description", "MD (m)", "Size (in)", "ID (in)",
                        "Joint (m)", "Weight (ppf)", "Grade", "Collapse (psi)", "Burst (psi)"}
    for key in ("hardware_table", "hardware_editor_draft"):
        hardware = data.get(key)
        if hardware is not None and not hardware_columns.issubset(hardware.columns):
            raise ValueError(f"{key} is missing required columns.")
        if hardware is not None:
            _check_table_numeric_cells(hardware, ("ID (in)", "Joint (m)", "Weight (ppf)",
                                                 "Collapse (psi)", "Burst (psi)"), key)
    validate_material_properties(data)


# F-03 (system audit 2026-09-29, owner-approved): the Phase VII lab grid is
# rendered with st.column_config.TextColumn editors (phase_7_lab), which
# reject non-string underlying dtypes with a raw StreamlitAPIException
# ("The configured column type 'text' for column 'Concentration' is not
# compatible for editing the underlying data type 'ColumnDataKind.FLOAT'").
# The app's own save path always writes strings into these columns, but a
# hand-edited or migrated project JSON can carry numeric cells (e.g.
# Concentration: 100.0); decode used to accept it and Phase VII crashed on
# first render. Coerce every text-valued grid column to strings at decode
# time — before any session write — while keeping missing cells (null/NaN)
# missing instead of fabricating "None"/"nan" text. Unit is a
# SelectboxColumn whose options are strings, so a non-string dtype there is
# equally foreign to the editor and gets the same treatment.
_LAB_GRID_TEXT_COLUMNS = ("Material", "Concentration", "Unit", "Mass", "Lot No")


def _is_missing_cell(cell):
    return cell is None or cell is pd.NA or (isinstance(cell, float) and math.isnan(cell))


def _coerce_text_columns(df, columns):
    if not isinstance(df, pd.DataFrame):
        return df
    for column in columns:
        if column not in df.columns:
            continue
        series = df[column]
        already_text = series.dtype == object and all(
            isinstance(cell, (str, type(None))) or _is_missing_cell(cell)
            for cell in series)
        if already_text:
            continue
        df[column] = pd.Series([cell if _is_missing_cell(cell) else str(cell)
                                for cell in series], index=series.index, dtype=object)
    return df


def _normalize_lab_grids(project):
    """F-03: decode-time dtype normalization for every lab grid the session
    will ever render — the active lab_grid_dfs AND the archived inactive-
    slurry drafts, which the enable-cycle later restores into lab_grid_dfs
    and would otherwise re-introduce the same crash after the load."""
    for grid in project.get("lab_grid_dfs", {}).values():
        _coerce_text_columns(grid, _LAB_GRID_TEXT_COLUMNS)
    for draft in project.get("inactive_slurry_drafts", {}).values():
        if isinstance(draft, dict):
            _coerce_text_columns(draft.get("lab_grid_dfs"), _LAB_GRID_TEXT_COLUMNS)
    return project


def normalize_hardware_text_columns(df):
    """Normalize accepted numeric depths/sizes without inventing missing cells."""
    return _coerce_text_columns(df, ("MD (m)", "Size (in)"))


def decode_project(raw_bytes, deserialize_item):
    """All parsing, reconstruction and shape checks occur without session writes."""
    loaded = json.loads(raw_bytes.decode("utf-8-sig"),
                        parse_constant=_reject_constant, object_pairs_hook=_unique_keys)
    if not isinstance(loaded, dict):
        raise ValueError("Project JSON must contain an object of project fields.")
    if any(not isinstance(k, str) for k in loaded):
        raise ValueError("Project field names must be strings.")
    project = {key: deserialize_item(value) for key, value in loaded.items() if is_project_key(key)}
    _check_finite(project)
    _normalize_lab_grids(project)
    _validate_project(project)
    restore_canonical_fields(project)
    _validate_project(project)
    for key in ("hardware_table", "hardware_editor_draft"):
        normalize_hardware_text_columns(project.get(key))
    migrate_material_properties(project)
    return project


def replace_project_state(state, project, signature, preserved_keys=()):
    """Commit the prepared state, restoring the original on any write failure."""
    previous = dict(state.items())
    preserved = {key: previous[key] for key in preserved_keys if key in previous}
    try:
        for key in list(state):
            if key not in preserved:
                del state[key]
        for key, value in project.items():
            state[key] = value
        state["last_loaded_hash"] = signature
        # The navigation radio was already mounted during this run. Its old
        # browser selection can remain checked after session replacement even
        # though the next run renders Phase I from the cleared widget state.
        state["_reset_navigation_to_phase1"] = True
    except Exception:
        for key in list(state):
            if key not in preserved:
                del state[key]
        for key, value in previous.items():
            if key not in preserved:
                state[key] = value
        raise
